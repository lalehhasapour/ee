angular.module('ngApp').controller('HomeCtrl', function ($scope, $http, $timeout) {

	$scope.slides = {};
	$scope.sliderLoading = '';
	$scope.slideroptions = {
		preventClicks: false,
		preventClicksPropagation: false,
		autoplayDisableOnInteraction: false,
		loop: true,
		speed: 400,
		autoplay: 6000,
	}

	$scope.$watch('sl', function () {
		if ($scope.mode) {
			$scope.sliderLoading = 'sliderLoading';
			$http({ method: 'GET', cache: true, noLoading: true, url: url + '/api/v1/widget/route/home-screen/getSlider/' + $scope.sl })
				.success(function (slider) {
					if (typeof slider.slides[0] !== 'undefined' && slider.slides[0].image) {
						$scope.slides = slider.slides;
						$scope.slideroptions = {
							preventClicks: false,
							preventClicksPropagation: false,
							autoplayDisableOnInteraction: false,
							loop: true,
							speed: 400,
							//autoHeight: true,
							autoplay: slider.autoplay * slider.duration * 1000,
							effect: slider.effect
						}
						$timeout(function () {
							$scope.sliderLoading = '';
						}, 5000);
					} else {
						$scope.sliderLoading = 'ng-hide';
					}
				})
				.error(function () {
					$scope.sliderLoading = '';
				});
		}
	});

	$scope.data = {};

	$scope.$watch('data.slider', function (slider) {

	});
})
