(function() {
	'use strict';
	angular.module('ngApp').requires.push(
		'ionic-ratings'
	);
	angular
		.module('ngApp.controllers', [])
		.controller('MainCtrl', MainController)
		.controller('NavCtrl', NavController)
		.controller('searchCtrl', searchController)
		.controller('CommentsCtrl', [
			'$scope',
			'$rootScope',
			'$http',
			'$timeout',
			'$ionicPopup',
			'$ionicPopup',
			CommentsCtrl
		]);

	MainController.$inject = ['$scope', '$rootScope', '$state', '$stateParams', '$ionicPopover', '$ionicConfig'];
	function MainController($scope, $rootScope, $state, $stateParams, $ionicPopover, $ionicConfig) {
		$rootScope.$state = $state;
		$scope.$state = $state.current;
		$scope.params = $stateParams;
		var theme = appsetting.theme ? appsetting.theme : 'default';
		var fontfamily = appsetting.fontFamily ? appsetting.fontFamily : 'vazir';
		$rootScope.appsetting = { theme : theme , fontfamily : fontfamily};

		var template = '<ion-popover-view class="readability"><ion-content class="padding"><button ng-if="share" ng-click="doShare($event)" class="button button-block button-clear button-light icon-right ion-share" title="global.share">اشتراک‌گذاری مطلب</button><div class="button-bar"><button class="button button-clear button-light big" onclick="increaseFontSize(15)">چ</button><button class="button button-clear button-light small" onclick="increaseFontSize(-15)">چ</button></div><div class="button-bar" style="margin-top:10px"><button class="button button-clear button-light big" onclick="increaseZoomLevel(10)"><i class="icon ion-search"></i></button><button class="button button-clear button-light small" onclick="increaseZoomLevel(-10)"><i class="icon ion-search"></i></button></div><div class="popover-row-dots row"><div class="col"><button class="popover-dot-white popover-dot" ng-class="appsetting.theme == \'default\' ? \'selected\' : \'\'" ng-click="changeColor(\'default\')"></button></div><div class="col"><button class="popover-dot-tan popover-dot" ng-class="appsetting.theme == \'tanTheme\' ? \'selected\' : \'\'" ng-click="changeColor(\'tanTheme\')"></button></div><div class="col"><button class="popover-dot-grey popover-dot" ng-class="appsetting.theme == \'greyTheme\' ? \'selected\' : \'\'" ng-click="changeColor(\'greyTheme\')"></button></div></div>'
					+ '<label class="item item-radio"><input type="radio" name="font" value="vazir" ng-model="appsetting.fontfamily" ng-click="changeFontFamily(\'vazir\')"><div class="item-content" style="font-family:vazir">وزیر</div><i class="radio-icon ion-checkmark"></i></label>'
							+ '<label class="item item-radio"><input type="radio" name="font" value="IRANSans" ng-model="appsetting.fontfamily" ng-click="changeFontFamily(\'IRANSans\')"><div class="item-content" style="font-family:IRANSans">ایران‌سنس</div><i class="radio-icon ion-checkmark"></i></label>'
					+ '<label class="item item-radio"><input type="radio" name="font" value="yekan" ng-model="appsetting.fontfamily" ng-click="changeFontFamily(\'yekan\')"><div class="item-content" style="font-family:yekan">یکان</div><i class="radio-icon ion-checkmark"></i></label>'
					+ '<label class="item item-radio"><input type="radio" name="font" value="tahoma" ng-model="appsetting.fontfamily" ng-click="changeFontFamily(\'tahoma\')"><div class="item-content" style="font-family:tahoma">tahoma</div><i class="radio-icon ion-checkmark"></i></label>'
				
		+ '</ion-content></ion-popover-view>';

		$scope.popover = $ionicPopover.fromTemplate(template, {
			scope: $scope
		});

		$scope.openSetting = function($event, options) {
			$scope.share = (options && options.share) ? true : false;
			if($scope.share) $scope.sharecontent = $(options.contentSelector).text();
			$scope.popover.show($event);
		}

		$scope.shareIt = function() {
			var tmp = document.createElement("DIV");
			tmp.innerHTML = $scope.sharecontent;
			window.plugins.socialsharing.share(getTextFromNode(tmp,true));
		}

		$rootScope.doShare = function(event) {
			$scope.popover.hide();
			var titleElem = document.getElementsByClassName('share-title');
			var messageElem = document.getElementsByClassName('share-message');
			var imageElem = document.getElementsByClassName('share-image');
			var urlElem = document.getElementsByClassName('share-url');
			var shareObj = {};
			if (titleElem && typeof titleElem[0] != "undefined") {
				titleElem = titleElem[0];
				shareObj.subject = titleElem.textContent;
			}
			if (messageElem && typeof messageElem[0] != "undefined") {
				messageElem = messageElem[0];
				shareObj.message = shareObj.subject ?
					shareObj.subject + " \n" + messageElem.innerText :
					messageElem.innerText;
			}
			if (imageElem && typeof imageElem[0] != "undefined") {
				imageElem = imageElem[0];
				shareObj.files = [imageElem.getAttribute('src')];
			}
			if (urlElem && typeof urlElem[0] != "undefined") {
				urlElem = urlElem[0];
				if (urlElem.dataset.shareUrl) {
					shareObj.url = urlElem.dataset.shareUrl;
				}
			}
			if (isDevice) {
				window.plugins.socialsharing.available(function (isAvailable) {
					if (isAvailable) {
						window.plugins.socialsharing.shareWithOptions(
							shareObj,
							function () {
								// callback on succeed
							},
							function () {
								// callback on failed
							}
						);
					}
				});
			} else {
				$rootScope.webAppShare(event, shareObj.message, shareObj.url);
			}
		};

		$scope.shareThisElement = function(selector) {
			var text = document.querySelector(selector).innerText;
			window.plugins.socialsharing.share(null , text, null, null);
		}

		$scope.changeColor = function(color) {
			$rootScope.appsetting.theme = color;
			appsetting['theme'] = color;
			saveSetting();
		}

		$scope.changeFontFamily = function(fontfamily) {
			$rootScope.appsetting.fontfamily = fontfamily;
			appsetting['fontFamily'] = fontfamily;
			saveSetting();
		}

		var sharePopoverTemplate = '<ion-popover-view style="width: 155px;height: 70px;"><ion-content class="padding">'+
				'<a href="https://telegram.me/share/url?url={{ shareUrl }}&text={{ shareTitle }}" target="_blank"				class="button button-icon icon ion-paper-airplane"></a>'+
				'<a href="https://wa.me/?text={{ shareTitle }} {{ shareUrl }}" target="_blank" class="button button-icon icon ion-social-whatsapp"></a>'+
				'<a href="https://twitter.com/intent/tweet?text={{ shareTitle }}&source=sharethiscom&related=sharethis&url={{ shareUrl }}" target="_blank" class="button button-icon icon ion-social-twitter"></a>'+
				'<a href="https://www.facebook.com/sharer.php?u={{ shareUrl }}" target="_blank" class="button button-icon icon ion-social-facebook"></a>'+
				'</ion-content></ion-popover-view>';

		$scope.sharePopover = $ionicPopover.fromTemplate(sharePopoverTemplate, {
			scope: $scope
		});

		$rootScope.webAppShare = function (event, title, url) {
			$scope.shareTitle = title;
			$scope.shareUrl = encodeURI(url);
			$scope.sharePopover.show(event);
		}
	}

	NavController.$inject = ['$scope', '$rootScope', '$ionicSideMenuDelegate', '$ionicModal', '$state'];
	function NavController($scope, $rootScope, $ionicSideMenuDelegate, $ionicModal, $state) {
		$scope.showMenu = function () {
			$ionicSideMenuDelegate.toggleLeft();
		};
		$scope.showRightMenu = function () {
			$ionicSideMenuDelegate.toggleRight();
		};
        $rootScope.toggleSideMenu = function () {
            $ionicSideMenuDelegate.toggleRight();
            $ionicSideMenuDelegate.toggleLeft();
        }
		$scope.isPurchased = function (product) {
			return $rootScope[product] ? 'ng-hide' : 'ng-show';
		};
				$ionicModal.fromTemplateUrl('more-modal.html', {
			scope: $scope,
			animation: 'slide-in-left',
			hardwareBackButtonClose: true
		}).then(function(modal) {
			$scope.moremodal = modal;
		});

		$scope.openMoreModal = function() {
			$scope.moremodal.show();
		};

		$scope.closeModal = function() {
			$scope.moremodal.hide();
		};
		
		$scope.changeState = function(to, params) {
			$state.go(to, params, {reload: false});
		};
	}
	
	searchController.$inject = ['$stateParams'];
	function searchController($stateParams) {
		if($stateParams.search){
			document.getElementById("searchable").innerHTML = doHighlight(document.getElementById("searchable").innerHTML,$stateParams.search);
		}
	}

	function CommentsCtrl($scope, $rootScope, $http, $timeout, $ionicPopup) {
		var vm = this;
		vm.reviews_options = [];
		vm.advantages_list = [];
		vm.disadvantages_list = [];
		vm.commentRate;
		$scope.commentAttach = '';
		vm.commentsSuggestion = {};
		vm.commentsSuggestion.selectedOccurrence = '';
		$scope.showCommentOption = false;
		// Wait until the sl var is init
		$scope.$watch('sl', function () {
			if (typeof $scope.sl != 'undefined') {
				$scope.getComments(false);
			}
		});
		vm.rateOption = {
			readOnly: false,
			rating: 0,
			minRating: 0,
			callback: function (rating, index) {
				vm.commentRate = rating;
			}
		};
		vm.rateOptions = {
			readOnly: false,
			rating: 0,
			minRating: 0,
			callback: function (rating, index) {
				vm.reviews_options[index] ={
					rate : rating,
					id : $scope.review_options[index].id,
				};
			}
		};
		$rootScope.closeImageViewerModal = function() {
            $rootScope.imageViewerModal.remove();
        };
		$scope.hideOptionsModal = function () {
			$scope.showCommentOption = false;
		}
		$scope.showOptionsModal = function () {
			$scope.showCommentOption = true;
		}
		$scope.openComment = function (comment, sl) {
            var new_sl = (typeof sl == 'undefined') ? $scope.sl : sl;
			window.location.href = '#/nav/widget/music/getComments/'+ new_sl +'/' + comment.widget_data_id + '/' + comment.id;
		};
		$scope.openSignup = function () {
			window.location.href = signupHash;
		};

		$scope.getComments = function (refresh) {
			if (isOnline()) {
				if (!refresh) {
					vm.loading = true;
				}
				$http({
					method: 'GET',
					noLoading: true,
					url: url + '/api/v1/comment/app/get-comments-data?sl=' + $scope.sl + '&parent_id='+ $scope.parent_id +'&length=10' + (($scope.show_my_comments) ? '&show_my_comments=true' : '')
				})
					.success(function (data) {
						$scope.$broadcast('scroll.refreshComplete');
						vm.comments = data.comments;
						if (vm.comments.length == 10) {
							vm.noMoreItemsAvailable = false;
						}
						vm.loading = false;
					})
					.error(function (error) {
						$scope.$broadcast('scroll.refreshComplete');
						vm.loading = false;
						checkYourInternet();
					});
			} else {
				vm.loading = false;
				showToast(lang('global.check_your_internet_connection'));
			}
		};
		
		$scope.sendMessage = function (commentMessage, parrentId, commentRate) {
			var fd = new FormData();
			fd.append('authToken', $rootScope.user.token);
			fd.append('sl', $scope.sl);
			fd.append('body', commentMessage);
			fd.append('rate',  JSON.stringify(commentRate));
			fd.append('advantages', vm.advantages_list);
			fd.append('disadvantages', vm.disadvantages_list);
			if (!!vm.commentsSuggestion.selectedOccurrence) {
				fd.append('commentsSuggestion', vm.commentsSuggestion.selectedOccurrence);
			}
			fd.append('review_options', JSON.stringify(vm.reviews_options));
			fd.append('parent_id', parrentId);
			fd.append('attach', vm.commentAttach);
            var success_comment_message = $scope.auto_confirm_is_active ? lang('global.comment_auto_confirm_message') : lang('global.comment_success_message');
			$http.post(url + '/api/v1/comment/app/store-comment', fd, {
				withCreadential : true,
				headers         : {
					'Content-Type': undefined,
				},
				transformRequest: angular.identity
			}).success(function (data) {
				if (data.success) {
					vm.commentsBody = "";
					vm.replyBody = "";
					$ionicPopup.alert({
						title   : lang('global.success'),
                        template: success_comment_message,
						okText  : lang('global.close')
					});
					$scope.getComments(true);
					$scope.hideOptionsModal();
				} else {
					showError(data.error);
				}
			}).error(function (err) {
				checkYourInternet();
			});
		};

		$scope.doRefresh = function () {
			$scope.getComments(true);
		};

		$scope.loadMore = function () {
			if (!vm.noMoreItemsAvailable) {
				vm.noMoreItemsAvailable = true;
				if (isOnline() && typeof vm.comments == "object") {
					var start = vm.comments.length;
					vm.infiniteScrollLoading = true;
					$http({
						method: 'GET',
						noLoading: true,
						url: url + '/api/v1/comment/app/get-comments-data?sl=' + $scope.sl + '&start=' + start + '&length=10'+ (($scope.show_my_comments) ? '&show_my_comments=true' : '')
					})
						.success(function (data) {
							if (data.comments.length == 0 || data.found == 0) {
								vm.noMoreItemsAvailable = true;
							} else {
								for (var i = 0; i < data.comments.length; i++) {
									vm.comments.push(data.comments[i]);
								}
							}
							vm.noMoreItemsAvailable = data.comments.length < 10;
							vm.infiniteScrollLoading = false;
							$scope.$broadcast('scroll.infiniteScrollComplete');
						})
						.error(function () {
							vm.infiniteScrollLoading = false;
							$scope.$broadcast('scroll.infiniteScrollComplete');
						});
				}
			}
		};

		$scope.addToAdvantage = function () {
			if (typeof vm.commentsAdvantage != 'undefined' && vm.commentsAdvantage != '') {
				vm.advantages_list.push(vm.commentsAdvantage);
				vm.commentsAdvantage = '';
			}
		};

		$scope.addToDisAdvantage = function () {
			if (typeof vm.commentsDisAdvantage != 'undefined' && vm.commentsDisAdvantage != '') {
				vm.disadvantages_list.push(vm.commentsDisAdvantage);
				vm.commentsDisAdvantage = '';
			}
		};

		$scope.removeFromLists = function (array_index, advantage) {
			if (advantage == 1) {
				vm.advantages_list.splice(array_index, 1);
			} else {
				vm.disadvantages_list.splice(array_index, 1);
			}
		};
	}
})();

function openPaymentUrl(url) {
	if (typeof cordova !== 'undefined' && typeof cordova.InAppBrowser !== 'undefined') {
		cordova.InAppBrowser.open(encodeURI(url), '_system');
	} else {
		// set cookie for back button in web applications
		createCookie('backUrl', window.location, 60);
		if (!isDevice && ionic.Platform.isIOS()) {
			window.location = encodeURI(url);
		} else {
			window.open(url, '_system');
		}
	}
}

function shareImage(subject, url, event) {
	// check url is remote or local file
	if (url.toLowerCase().startsWith("http") && !url.toLowerCase().startsWith("http://localhost/")) {
		if (isDevice) {
			window.plugins.socialsharing.share(null, subject, url, null);
		} else {
			angular.element(document.body).injector().get('$rootScope').webAppShare(event, subject, url);
		}
	} else {
		// Create an empty canvas element
		var canvas = document.createElement("canvas");
		var img = new Image();
		var ctx = canvas.getContext("2d");
		img.onload = function () {
			canvas.width = img.width;
			canvas.height = img.height;
			// Copy the image contents to the canvas
			ctx.drawImage(img, 0, 0, img.width, img.height);
			// Get the data-URL formatted image
			var dataURL = canvas.toDataURL("image/png");
			window.plugins.socialsharing.share(null, subject, dataURL, null);
		}
		img.src = url;
	}
}
