var $signupVersion = 3.1;
var inappbilling_inited = false;

(function () {
    'use strict';

    angular.module('ngApp').requires.push('ngFileUpload', 'ionic-datepicker', 'ionic', 'ngMessages', 'mgo-angular-wizard');

    angular
        .module('ngApp')
        .controller('profileCtrl', profileController)
        .controller('signupCtrl', SignupController)
        .controller('LoginCtrl', LoginController)
        .controller('EditCtrl', editProfileController)
        .controller('ticketsCtrl', ticketsController)
        .controller('ticketCtrl', ticketController)
        .controller('ticketViewCtrl', ticketViewController)
        //This is a suitable syntax for minification
        .controller('PlanCtrl', ['$scope', '$http', 'Auth', '$ionicLoading', '$q', '$ionicPopup', planController])
        .controller('walletCtrl', ['$scope', '$http', '$ionicLoading', 'Auth', 'localStorage', walletController])
        .factory('Auth', AuthenticationService)
        .factory('UserService', UserService)
        .filter('join', joinFilter)
        .filter('fixConditionalValue', fixConditionalValueFilter)
        .directive('customOnChange', function () {
            return {
                restrict: 'A',
                link    : function (scope, element, attrs) {
                    var onChangeFunc = scope.$eval(attrs.customOnChange);
                    element.bind('change', onChangeFunc);
                    element.on('$destroy', function () {
                        element.off();
                    });
                }
            };
        }).run(function ($rootScope, $timeout) {
            $rootScope.signupVersion = $signupVersion;
            $rootScope.$on('$stateChangeStart', function () {
                if (
                    !$widgets.data.signup.checkForMustLogin &&
                    $widgets.data.signup.must_register &&
                    !($rootScope.user && $rootScope.user.isLogin)
                ) {
                    if (window.location.hash !== ('#/nav/' + $widgets.data.signup.page_slug)) {
                        $widgets.data.signup.redirectAfterLogin = window.location.hash;
                    }
                    $widgets.data.signup.checkForMustLogin = true;
                    $timeout(function () {
                        $rootScope.goToStateWithDisableBack('nav.' + $widgets.data.signup.page_slug);
                    });
                }
            });

            $rootScope.goToLandingAfterLogin = function () {
                if (!!$widgets.data.signup.redirectAfterLogin) {
                    window.location.hash = $widgets.data.signup.redirectAfterLogin;
                } else {
                    $rootScope.goToStateWithDisableBack(homeState);
                }
            };
        });

    function planController($scope, $http, Auth, $ionicLoading, $q, $ionicPopup) {
        
        $scope.targetMarket = $app_data.target_market;

        $scope.checkTargetExports = function (plan) {
           return plan.targetExports.includes( $scope.targetMarket ) || $scope.targetMarket == 'web' || plan.targetExports.length == 0 ? true : false;
        }

        var fetchPlans = function () {
            return $http({
                method: 'GET',
                url   : url + '/api/v1/widget/get/signup/getPlans',
                params: {
                    sl: $widgets.data.signup.sl
                }
            }).success(function (result) {
                return result;
            }).error(function (e) {
                return e;
            });
        };

        var loadPlans = function () {
            return fetchPlans().then(function (result) {
                if (typeof result.status === undefined || result.status !== 200) {
                    return;
                }
                if (result.data.success !== true) {
                    return;
                }
                $scope.plans = JSON.parse(result.data.payload.plans);
                if ($widgets.data.signup.providerName !== 'cafebazaar' &&
                    $widgets.data.signup.providerName !== 'myket') {
                    $scope.coupon_active = result.data.payload.coupon_active;
                }
                $scope.plans = $scope.plans.filter($scope.checkTargetExports)
            });
        };

        $scope.$watch('plans', function () {
            if ($scope.plans.length == 1) {
                $scope.selectPlan($scope.plans[0]);
            }
        });

        var planPaymentRequest = function () {
            if ($widgets.data.signup.providerName === 'cafebazaar' ||
                $widgets.data.signup.providerName === 'myket'
            ) {
                var productId = $scope.selectedPlan.productId;
                var type = $scope.selectedPlan.periodInDays == -1 ? 'buy' : 'subscribe';
                if ($widgets.data.signup.providerName === 'myket') {
                    type = 'buy';
                }
                return $q(function (resolve, reject) {
                    return resolve(inappPlanPaymentRequest(productId, type));
                });
            }
            return $http({
                method      : 'POST',
                url         : url + '/api/v1/widget/post/signup/planPaymentRequest',
                data        : {
                    plan    : $scope.selectedPlan,
                    coupon  : $scope.coupon,
                    user    : Auth.User,
                    provider: $widgets.data.signup.providerName
                },
                params      : {sl: $widgets.data.signup.sl},
                responseType: 'json',
            });
        };

        var inappPlanPaymentRequest = function (productId, type) {
            var finalResponse = {
                data: {
                    success: false,
                    payload: {
                        provider: $widgets.data.signup,
                    },
                },
            };
            if (!isDevice) {
                showWarning(lang('signup.not_available_in_similator'));
                finalResponse.data.error = 'This feature is only available in application';
                return finalResponse;
            }
            if (!isOnline()) {
                checkYourInternet();
                finalResponse.data.error = 'Check your internet connection';
                return finalResponse;
            }
            $ionicLoading.show();
            var proccessBuy = function () {
                inappbilling[type](
                    function (result) {
                        verifyInappPlanPayment(result, type, $widgets.data.signup.sl);
                    },
                    function () {
                        //sendLogForTryPlanPayment(result, type);
                        $ionicLoading.hide();
                        showError(lang('signup.payment_failed'));
                        return;
                    },
                    productId
                );
            };
            if (inappbilling_inited) {
                proccessBuy();
            } else {
                inappbilling.init(function () {
                        inappbilling_inited = true;
                        proccessBuy();
                    }, function () {
                        showWarning(
                            lang('signup.fail_iap_message1') +
                            $widgets.data.signup.providerName +
                            lang('signup.fail_iap_message2')
                        );
                        setTimeout(function () {
                            $widgets.data.signup.providerName === 'cafebazaar' ?
                                window.open('bazaar://login', '_system') :
                                window.open('myket://details', '_system');
                        }, 3000);
                    },
                    {showLog: false},
                    $widgets.data.signup.providerName === 'cafebazaar' ?
                        'com.farsitel.bazaar' : 'ir.mservices.market',
                    $widgets.data.signup.providerName === 'cafebazaar' ?
                        'ir.cafebazaar.pardakht.InAppBillingService.BIND' :
                        'ir.mservices.market.InAppBillingService.BIND',
                    $widgets.data.signup.RSAKey);
            }
        };

        var verifyInappPlanPayment = function (result, type, sl) {
            $ionicLoading.show();
            $http({
                method: 'POST',
                // @todo implement this method at backend
                url         : url + '/api/v1/widget/post/signup/verifyInappPlanPayment?sl=' + sl,
                data        : {
                    packageName  : result.packageName,
                    productId    : result.productId,
                    purchaseToken: result.purchaseToken,
                    provider     : $widgets.data.signup.providerName,
                    code         : result.code,
                    type         : type,
                },
                responseType: 'json'
            })
                .success(function (data) {
                    $ionicLoading.hide();
                    if (data.success === true) {
                        planInappPaymentSucceeded(result.productId);
                    } else {
                        showError(data.error);
                    }
                }).error(function () {
                $ionicLoading.hide();
                $ionicPopup.alert({
                    cssClass: 'iap_pupop',
                    title   : '',
                    template: lang('signup.fail_iap_confirm'),
                    buttons : [{
                        text : '<b>تلاش مجدد</b>',
                        type : 'button-positive',
                        onTap: function () {
                            verifyInappPlanPayment(result, type, sl);
                        }
                    }, {
                        text: 'بستن',
                        type: 'button-stable'
                    }]
                });
            });
        };

        var planInappPaymentSucceeded = function (productId) {
            Auth.UpdateUser();
            $ionicPopup.show({
                cssClass: 'iap_pupop',
                title   : lang('signup.payment_successed'),
                template: $scope.selectedPlan.message,
                buttons : [{
                    text: lang('global.close'),
                    type: 'button-clear button-balanced'
                }],
            });
            inappbilling.consumePurchase(function () {
            }, function (e) {
                console.log(e);
            }, productId);
            window.location.hash = homeHash;
        }

        var sendLogForTryPlanPayment = function (result, type) {
            $http({
                method      : 'POST',
                url         : url + '/api/v1/widget/post/signup/saveLogInAppPlanPayment?sl=' + $widgets.data.signup.sl,
                data        : {
                    packageName: result.packageName,
                    productId  : result.productId,
                    provider   : $widgets.data.signup.providerName,
                    code       : result.code,
                    type       : type,
                },
                responseType: 'json'
            });
        }

        $scope.init = function () {
            $scope.selectedPlan = undefined;
            $scope.plans = [];
            $scope.coupon = '';
            loadPlans();
        };

        $scope.selectPlan = function (plan) {
            $scope.selectedPlan = plan;
        };

        $scope.purchasePlan = function () {
            // if (!$scope.selectedPlan) {
            //     return;
            // }
            var windowReference = null;
            if ($widgets.data.signup.providerName !== 'cafebazaar'
                && $widgets.data.signup.providerName !== 'myket'
                && ionic.Platform.isIOS()) {
                windowReference = window;
            }
            planPaymentRequest()
                .then(function (response) {
                    if (typeof response === 'undefined') {
                        return;
                    }
                    if (typeof response.data === 'undefined') {
                        return;
                    }
                    if (!response.data.success) {
                        if ($widgets.data.signup.providerName == 'wallet') {
                            $widgets.functions.signup.showWalletPaymentError(response.data.error);
                        } else {
                            showWarning(response.data.error);
                        }
                        return;
                    }
                    if (response.data.payload.provider == 'wallet') {
                        showSuccess(lang('signup.upgrade_successfuly'));
                        setTimeout(function () {
                            $widgets.functions.signup.updateUser();
                            window.location.hash = homeHash;
                        }, 2000);
                    } else {
                        openPaymentUrl(response.data.payload.paymentUrl);
                        ionic.Platform.exitApp();
                    }
                }, function (e) {
                    showWarning(e);
                });
        };

        $scope.setCoupon = function (coupon) {
            $scope.coupon = coupon;
        };

        $scope.checkCoupon = function () {
            $ionicLoading.show();
            $http({
                method      : 'POST',
                url         : url + '/api/v1/widget/post/signup/checkCoupon',
                data        : {
                    sl    : $widgets.data.signup.sl,
                    coupon: $scope.coupon,
                    plan  : $scope.selectedPlan
                },
                responseType: 'json'
            }).success(function (data) {
                $ionicLoading.hide();
                if (data.success === true) {
                    showSuccess(data.message);
                } else {
                    showError(data.error);
                }
            }).error(function () {
                $ionicLoading.hide();
                checkYourInternet();
            });
        };
    }

    angular.module('ngApp').service('termsModalService', function ($ionicModal, $rootScope) {

        this.showTermsModal = function () {
            $ionicModal.fromTemplateUrl('terms.html', {
                scope                  : null,
                animation              : 'slide-in-up',
                hardwareBackButtonClose: true
            }).then(function (modal) {
                $rootScope.openModal = modal;
                modal.show();
            });
        };
    });

    angular.module('ngApp').service('privacyPolicyModalService', function ($ionicModal, $rootScope) {
        this.showPrivacyPolicyModal = function () {
            $ionicModal.fromTemplateUrl('privacyPolicy.html', {
                scope                  : null,
                animation              : 'slide-in-up',
                hardwareBackButtonClose: true
            }).then(function (modal) {
                $rootScope.openModal = modal;
                modal.show();
            });
        };
    });


    function walletController($scope, $http, $ionicLoading, Auth, localStorage) {
        var vm = this;
        var provider = $widgets.data.signup.walletProviderName;
        $scope.version = $signupVersion;
        $scope.customAmount = provider != 'cafebazaar' && provider != 'myket';
        $scope.pay = function (amount, productId) {
            if (amount > 0) {
                if (provider == 'cafebazaar' || provider == 'myket') {
                    payInAppPurchase(productId);
                } else {
                    getPurchaseLink(amount).then(function (result) {
                        if (result.data.success) {
                            openPaymentLink(result.data.payload.paymentUrl);
                        } else {
                            showError(result.data.message);
                        }
                    });
                }
            }
        };

        $scope.copyCode = function (text) {
            copyToClipboard(text);
        };

        function payInAppPurchase(productId) {
            if (!isDevice) {
                showWarning(lang('signup.not_available_in_similator'));
                return;
            }
            if (!isOnline()) {
                checkYourInternet();
                return;
            }
            $ionicLoading.show();
            var buyProcess = function () {
                inappbilling.buy(
                    verifyInappPayment, //success call back
                    showPaymentError, // error callback
                    productId
                );
            };

            var verifyInappPayment = function (result) {
                $ionicLoading.show();
                $http({
                    method      : 'POST',
                    url         : url + '/api/v1/widget/post/signup/verifyInappWalletPayment?sl=' + $widgets.data.signup.sl,
                    data        : {
                        packageName  : result.packageName,
                        productId    : result.productId,
                        purchaseToken: result.purchaseToken,
                        provider     : $widgets.data.signup.walletProviderName,
                        code         : result.code,
                        type         : 'buy',
                    },
                    responseType: 'json'
                })
                    .success(function (data) {
                        $ionicLoading.hide();
                        if (data.success === true) {
                            Auth.UpdateUser();
                            inappbilling.consumePurchase(function () {
                            }, function (e) {
                                console.log(e);
                            }, result.productId);

                            showSuccess(lang('signup.wallet_payment_successfully') + data.payload.newBalance);
                        } else {
                            showError(data.error);
                        }
                    }).error(function () {
                    $ionicLoading.hide();
                    $ionicPopup.alert({
                        cssClass: 'iap_pupop',
                        title   : '',
                        template: lang('signup.fail_iap_confirm'),
                        buttons : [{
                            text : '<b>تلاش مجدد</b>',
                            type : 'button-positive',
                            onTap: function () {
                                verifyInappPayment(result);
                            }
                        }, {
                            text: 'بستن',
                            type: 'button-stable'
                        }]
                    });
                });
            };

            var showPaymentError = function () {
                $ionicLoading.hide();
                showError(lang('signup.payment_failed'));
            };

            var failInit = function () {
                $ionicLoading.hide();
                showWarning(
                    lang('signup.fail_iap_message1') +
                    provider +
                    lang('signup.fail_iap_message2')
                );
                setTimeout(function () {
                    provider === 'cafebazaar' ?
                        window.open('bazaar://login', '_system') :
                        window.open('myket://details', '_system');
                }, 3000);
            };

            if (inappbilling_inited) {
                buyProcess();
            } else {
                inappbilling.init(function () {
                    inappbilling_inited = true;
                    buyProcess();
                }, failInit, {showLog: false}, '', '', $widgets.data.signup.RSAKey);
            }
        }

        function getPurchaseLink(amount) {
            return $http({
                method      : 'POST',
                url         : url + '/api/v1/widget/post/signup/walletPaymentRequest',
                data        : {
                    amount  : amount,
                    provider: $widgets.data.signup.walletProviderName,
                    sl      : $widgets.data.signup.sl
                },
                responseType: 'json',
            }).error(function (e) {
                checkYourInternet();
            });
        }

        function openPaymentLink(link) {
            window.walletPaymentSucceed = function () {
                Auth.UpdateUser();
            };
            openPaymentUrl(link);
        }

        vm.noMoreItemsAvailable = true;
        vm.items = [];
        vm.getWalletHistory = function (refresh) {
            $http({
                method      : 'POST',
                url         : url + '/api/v1/widget/post/signup/getWalletHistory',
                data        : {
                    sl    : $widgets.data.signup.sl,
                    start : refresh ? 0 : vm.items.length,
                    length: 10
                },
                responseType: 'json'
            })
                .success(function (result) {
                    if (refresh) vm.items = [];
                    if (result.success === true) {
                        for (var i = 0; i < result.payload.items.length; i++) {
                            vm.items.push(result.payload.items[i]);
                        }
                        vm.noMoreItemsAvailable = result.payload.items.length < 10;
                    }
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    $scope.$broadcast('scroll.refreshComplete');
                }).error(function () {
                checkYourInternet();
                $scope.$broadcast('scroll.infiniteScrollComplete');
                $scope.$broadcast('scroll.refreshComplete');
            });
        };

        vm.withdrawInit = function () {
            var user_bank_info = localStorage.all('user_bank_info');
            vm.card_number = user_bank_info.card_number || '';
            vm.shaba_number = user_bank_info.shaba_number || '';
        };
        vm.drawWallet = function (isValid) {
            if (!isValid) {
                return showWarning(lang('signup.form_invalid'));
            }
            localStorage.save({
                card_number: vm.card_number,
                shaba_number: vm.shaba_number
            }, 'user_bank_info');
            $http({
                method      : 'POST',
                url         : url + '/api/v1/widget/post/signup/reqForWithdraw',
                data        : {
                    sl          : $widgets.data.signup.sl,
                    amount      : vm.withdraw_amount,
                    card_number : vm.card_number,
                    shaba_number: vm.shaba_number,
                },
                responseType: 'json'
            }).success(function (result) {
                showSuccess(lang('signup.withdraw_requested'), 2400);
            }).error(function () {
                checkYourInternet();
            });
        };

        vm.cancelWithdrawReq = function (id) {
            $http({
                method      : 'POST',
                url         : url + '/api/v1/widget/post/signup/cancelWithdrawReq',
                data        : {
                    sl    : $widgets.data.signup.sl,
                    req_id: id,
                },
                responseType: 'json'
            }).success(function (result) {
                showSuccess(lang('signup.cancelWithdraw_request'), 2400);
            }).error(function () {
                checkYourInternet();
            });
        };
    }

    /**
     * Profile page Controller
     * show user data
     * @type {Controller}
     * @param {Auth} Authentication Service
     */
    profileController.$inject = ['$scope', '$rootScope', '$http', 'Auth'];

    function profileController($scope, $rootScope, $http, Auth) {

        $scope.isUserExpired = function (user) {
            return (new Date(user.expire_date)) < (new Date());
        };

        $scope.version = $signupVersion;
        $scope.hasWallet = $widgets.data.signup.hasWallet;
        $scope.hasScore =  $widgets.data.signup.hasScore;

        $scope.init = function () {
            $scope.$emit('pzz_signup.profile_loaded');
            $(".badge-for-submenus").each(function (index, element) {
                var url = $(element).attr('data-link');
                $.ajax({
                    type    : 'GET',
                    url     : url,
                    dataType: 'json',
                    encode  : true,
                }).done(function (d) {
                    if (d.success && d.count != 0) {
                        $(element).show();
                        $(element).text(d.count);
                    } else {
                        $(element).hide();
                    }
                }).fail(function (d) {
                    console.log('fail to get counts of badges');
                }).always(function () {
                });
            });
            $scope.showExtraData();
        };

        $scope.logout = function () {
            Auth.Logout();
        };

        $scope.change_password = function (isValid) {
            if (isValid) {
                Auth.ChangePassword($scope.oldPassword, $scope.newPassword, function (response) {
                    if (response.success) {
                        showSuccess(lang('signup.password_changed_successfully_message'), 2400);
                        setTimeout(function () {
                            $rootScope.goToStateWithDisableBack(homeState);
                        }, 2500);
                    } else {
                        showWarning(response.message);
                    }
                });
            } else {
                showWarning(lang('signup.form_invalid'));
            }
        };

        $scope.showExtraData = function () {
            $scope.extraDataFields = [];            
            Object.keys($rootScope.user.extra_data).forEach(function(key){
                let field = $rootScope.user.extra_data[key];
                if (field.showInProfile == 1) {
                    $scope.extraDataFields.push(field);
                }
            })
        }
    }

    /**
     * Edit Profile page Controller
     * show input of user data for update
     * @type {Controller}
     * @param {Auth} Authentication Service
     */
    editProfileController.$inject = ['$scope', 'Auth', 'ionicDatePicker', 'ionicTimePicker', '$timeout', '$ionicPopup'];

    function editProfileController($scope, Auth, ionicDatePicker, ionicTimePicker, $timeout, $ionicPopup) {

        $scope.edit = angular.copy(Auth.User);
        $scope.editimagesets = $scope.edit.profile_pic != '' ? true : false;
        $scope.model = typeof $scope.model === 'undefined' ? {} : $scope.model;
        $scope.model.profile_pic = $scope.edit.profile_pic;
        $scope.model.files = {};
        $scope.onFileChange = onFileChange;
        $scope.version = $signupVersion;

        $scope.submitform = function (isValid) {
            if (isValid) {
                var form_data = $('#editForm').serializeObject();
                var password = form_data.password;
                form_data.profile_pic = $scope.model.profile_pic;
                Object.keys($scope.model.files).forEach(function (key) {
                    form_data[key] = $scope.model.files[key];
                });
                Auth.Update(form_data, function (response) {
                    if (response.success) {
                        showSuccess(lang('signup.successfully_edited'), 1000);
                        setTimeout(function () {
                            var isUserActive = Boolean(response.payload.userIsActive);
                            if (!isUserActive) {
                                Auth.Logout();
                                if (response.payload.verification == 'by_email') {
                                    $ionicPopup.alert({
                                        title   : lang('signup.confirm_email'),
                                        template: lang('signup.email_send_successfully'),
                                        okText  : lang('signup.confirm_message'),
                                    }).then(function () {
                                        window.location.hash = signupHash;
                                    });
                                } else if (response.payload.verification == 'by_cellphone') {
                                    Auth.username = response.payload.user.username;
                                    Auth.password = password;
                                    window.location.hash = '#/nav/widget/signup/confirmCellphone/' + $widgets.data.signup.sl + '/' + response.payload.user.user_id;
                                }
                            } else {
                                window.location.hash = signupHash;
                            }
                        }, 1100);
                    } else {
                        showWarning(response.message);
                    }
                });
            } else {
                showWarning(lang('signup.form_invalid'));
            }
        }

        var datevalue = false, timevalue = false;
        $scope.openDatePicker = function (model, time, isExtraData = true) {
            ionicDatePicker.openDatePicker({
                callback : function (unix, dateString) {
                    datevalue = unix;
                    if(isExtraData){
                        $scope['edit']['extra_data'][model]['value'] = dateString;
                    }else{
                        $scope['edit'][model] = dateString;
                    }
                    if (time) {
                        ionicTimePicker.openTimePicker({
                            callback : function (val) {
                                timevalue = val;
                                var selectedTime = typeof (val) === 'undefined' ? new Date() : new Date(val * 1000);
                                if(isExtraData){
                                    $scope['edit']['extra_data'][model]['value'] = dateString + ' - ' + selectedTime.getUTCHours() + ':' + selectedTime.getUTCMinutes();;
                                }else{
                                    $scope['edit'][model] = dateString + ' - ' + selectedTime.getUTCHours() + ':' + selectedTime.getUTCMinutes();;
                                }
                            },
                            inputTime: timevalue != false ? timevalue : (new Date()).getHours() * 60 * 60,
                        });
                    }
                },
                inputDate: datevalue != false ? new Date(datevalue) : new Date(),
            });
        };

        $scope.openTimePicker = function (model) {
            ionicTimePicker.openTimePicker({
                callback : function (val) {
                    timevalue = val;
                    var selectedTime = typeof (val) === 'undefined' ? new Date() : new Date(val * 1000);
                    $scope['edit']['extra_data'][model]['value'] = selectedTime.getUTCHours() + ':' + selectedTime.getUTCMinutes();
                },
                inputTime: timevalue != false ? timevalue : (new Date()).getHours() * 60 * 60,
            });
        };

        $scope.validateFile = function (files) {
            if (files != null) {
                var file = files[0];
                if (window.FileReader != null && typeof file != "undefined" && typeof file.type != "undefined") {
                    if (file.size < 5 * 1024 * 1024) {
                        $timeout(function () {
                            var fileReader = new FileReader();
                            fileReader.readAsDataURL(file); // convert the image to data url.
                            fileReader.onload = function (e) {
                                $timeout(function () {
                                    if (file.type.indexOf('image') > -1) {
                                        $scope.imagesets = true;
                                        $scope.model.profile_pic = e.target.result;
                                    } else {
                                        showWarning(lang('signup.the_file_type_is_not_allowed'));
                                    }
                                });
                            }
                        });
                    } else {
                        showWarning(lang('signup.maximum_authorized_volume_is_5m'));
                    }
                } else {
                    $scope.imagesets = false;
                    showWarning(lang('signup.the_file_is_not_valid'));
                }
            }
        };

        $scope.showChangePassword = true;

        function onFileChange() {
            var files = event.target.files;
            var file = files[0];
            var fieldName = event.target.name;
            var allowedType = /image\/*|audio\/*|video\/*|pdf|zip|word/i;
            if (window.FileReader != null && typeof file != "undefined" && typeof file.type != "undefined" && !!allowedType.exec(file.type)) {
                if (file.size < 10 * 1024 * 1024) {
                    var fileReader = new FileReader();
                    // This event is triggered each time the reading operation is successfully completed.
                    fileReader.onload = function (e) {
                        $scope.model.files[fieldName] = e.target.result;
                        $scope.$apply();
                        if (file.type.indexOf('image') > -1) {
                            $('#' + fieldName + "_btn").addClass('fill').removeClass('video pdf other audio').css('background-image', 'url(' + e.target.result + ')');
                        } else if (file.type.indexOf('audio') > -1) {
                            $('#' + fieldName + "_btn").addClass('fill audio').removeClass('video pdf other').css('background-image', 'none');
                        } else if (file.type.indexOf('video') > -1) {
                            $('#' + fieldName + "_btn").addClass('fill video').removeClass('audio pdf other').css('background-image', 'none');
                        } else if (file.type.indexOf('pdf') > -1) {
                            $('#' + fieldName + "_btn").addClass('fill pdf').removeClass('video audio other').css('background-image', 'none');
                        } else {
                            $('#' + event.target.name + "_btn").addClass('fill other').removeClass('video pdf audio').css('background-image', 'none');
                        }
                    }
                    fileReader.readAsDataURL(file);
                } else {
                    $("#" + fieldName).val('');
                    $scope.model.files[fieldName] = '';
                    $scope.$apply();
                    $ionicPopup.alert({
                        title   : lang('forms.error'),
                        template: lang('forms.maximum_file_size'),
                        okText  : lang('forms.close')
                    });
                }
            } else {
                $("#" + fieldName + "_btn").removeClass('fill video pdf other audio').css('background-image', 'none');
                $("#" + fieldName + "_name").val('');
                $("#" + fieldName + "_file").val('');
                $ionicPopup.alert({
                    title   : lang('forms.error'),
                    template: lang('forms.file_not_valid'),
                    okText  : lang('forms.close')
                });
            }
        }

        $scope.deleteAccount = function () {
            $ionicPopup.show({
                cssClass: 'delete-acount',
                title   : lang('signup.delete_account'),
                template: lang('signup.delete_account_message'),
                scope   : $scope,
                buttons : [{
                    text: lang('signup.cancel'),
                    type: 'button-balanced button-clear'
                }, {
                    text : lang('signup.delete_account'),
                    type : 'button-assertive button-clear',
                    onTap: function (e) {
                        $ionicPopup.show({
                            cssClass: 'delete-acount-confirm',
                            title   : lang('signup.delete_account'),
                            template: lang('signup.delete_account_message2'),
                            scope   : $scope,
                            buttons : [{
                                text: lang('signup.cancel'),
                                type: 'button-balanced button-clear'
                            }, {
                                text : lang('signup.i_am_sure_delete_account'),
                                type : 'button-assertive button-clear',
                                onTap: function (e) {
                                    Auth.Delete(function (response) {
                                        if (response.success) {
                                            showSuccess(lang('signup.account_deleted_permanently'));
                                            Auth.Logout();
                                            window.location.hash = homeHash;
                                        } else {
                                            showError(response.error);
                                        }
                                    });
                                }
                            }]
                        });
                    }
                }]
            });
        };
    }

    /**
     * signup form Controller
     * @type {Controller}
     * @param {Auth} Authentication Service
     */
    SignupController.$inject = ['$ionicScrollDelegate', '$http', '$scope', '$rootScope', '$timeout', 'Auth', 'UserService', '$ionicPopup', '$interval', 'ionicDatePicker', 'ionicTimePicker', 'termsModalService', 'privacyPolicyModalService'];

    function SignupController($ionicScrollDelegate, $http, $scope, $rootScope, $timeout, Auth, UserService, $ionicPopup, $interval, ionicDatePicker, ionicTimePicker, termsModalService, privacyPolicyModalService) {
        $scope.imagesets = false;
        $scope.model = {
            cellphone: $rootScope.cellphone
        };
        $scope.model.files = {};
        $scope.confirmMetode = '';
        $scope.time = 90;
        $scope.codeComplete = false;
        $scope.termsModalService = termsModalService;
        $scope.privacyPolicyModalService = privacyPolicyModalService;
        $scope.onFileChange = onFileChange;
        $scope.version = $signupVersion;
        $scope.currentStep = 0;
        $scope.codeArray;

        if (!Auth.User.isLogin)
            $rootScope.hideTabs = true;

        $scope.collectCodes = function () {
            var getinputs = document.getElementsByClassName("confirm-input");
            var total = '';
            for (var i = 0; i < 6; i++) {
                total = total + getinputs[i].value;
            }
            $scope.code = parseInt(total);
            if (total.length == 6) {
                $scope.codeComplete = true;
            } else {
                $scope.codeComplete = false;
            }
        }
        function fetchSteps() {
            return $http({
                method: 'GET',
                url   : url + '/api/v1/widget/get/signup/getStepInputs',
                params: {
                    sl: $widgets.data.signup.sl
                }
            }).success(function (result) {
                $scope.fields = result.payload.steps;
                $scope.fields_size = Object.keys($scope.fields).length;
            }).error(function (e) {
                return e;
            });
        };
        fetchSteps();

        $scope.checkValidation = function (form) {
            showWarning(lang('signup.enter_form_valid'), 1000);
            form.$setSubmitted();
        }

		$scope.showNextButton = function () {
			var check = $scope.fields_size !== $scope.currentStep + 1;
			return check;
		}
        $scope.$on('wizard:stepChanged', function (event, data) {
			$timeout(function() {
				$ionicScrollDelegate.$getByHandle('signupScroll').scrollTop();
			});
			$timeout(function() {
				$ionicScrollDelegate.$getByHandle('signupScroll').resize();
			}, 300);
            $scope.currentStep = data.step.wzData.step;
		});
		$scope.onSubmit = function() {
            console.log('submit');
        }

        function handleSmsCode(data) {
            $scope.codeArray = data;
            $scope.codeArray = $scope.codeArray.slice(0, 6).split("");
            if (!$scope.codeArray.join("").match(/^[0-9]|[۰-۹]|[٠-٩]+$/)) console.log("Invalid pasted data");
            for (var index = 0; index < $scope.codeArray.length; index++) {
                document.getElementsByClassName("confirm-input")[index].value = $scope.codeArray[index];
            }
            $scope.collectCodes();
            $scope.submitLoginWithPhone(true);
        }

        $scope.handleOnPaste = function (event) {
            event.preventDefault();
            var item = event.originalEvent.clipboardData.items[0];
            item.getAsString(function (data) {
                handleSmsCode(data)
            });
        }

        document.addEventListener('onSMSArrive', function(args) {
            var smsRegex = /\b\d{6}\b/;
            var code = args.message.match(smsRegex);
            handleSmsCode(code[0]);
            stopSMSWatch();
        });

        function stopSMSWatch() {
            if(typeof cordova !== "undefined" && cordova.plugins && cordova.plugins.SMSRetriever) {
                cordova.plugins.SMSRetriever.stopWatch()
            }
        }

        $scope.nextInput = function (elmnt) {
            if (elmnt.which === 8) {
                if (elmnt.currentTarget.tabIndex != 1) {
                    $scope.back = elmnt.currentTarget.tabIndex;
                    $scope.back--;
                    $('.confirm-input[tabindex=' + $scope.back + ']').removeAttr('value');
                    $('.confirm-input[tabindex=' + $scope.back + ']').focus();
                    $('.confirm-input[tabindex=' + $scope.back + ']').select();
                }
            } else {
                if (elmnt.currentTarget.tabIndex != 6) {
                    $scope.next = elmnt.currentTarget.tabIndex;
                    $scope.next++;
                    $('.confirm-input[tabindex=' + $scope.next + ']').focus();
                    $('.confirm-input[tabindex=' + $scope.next + ']').select();
                }
            }
        }

        function onFileChange(event) {
            var files = event.target.files;
            var file = files[0];
            var fieldName = event.target.name;
            if (window.FileReader != null && typeof file != "undefined" && typeof file.type != "undefined") {
                if (file.size < 10 * 1024 * 1024) {
                    var fileReader = new FileReader();
                    // This event is triggered each time the reading operation is successfully completed.
                    fileReader.onload = function (e) {
                        $scope.model.files[fieldName] = e.target.result;
                        $scope.model[fieldName] = 'filled';
                        $scope.$apply();
                        if (file.type.indexOf('image') > -1) {
                            $('#' + fieldName + "_btn").addClass('fill').removeClass('video pdf other audio').css('background-image', 'url(' + e.target.result + ')');
                        } else if (file.type.indexOf('audio') > -1) {
                            $('#' + fieldName + "_btn").addClass('fill audio').removeClass('video pdf other').css('background-image', 'none');
                        } else if (file.type.indexOf('video') > -1) {
                            $('#' + fieldName + "_btn").addClass('fill video').removeClass('audio pdf other').css('background-image', 'none');
                        } else if (file.type.indexOf('pdf') > -1) {
                            $('#' + fieldName + "_btn").addClass('fill pdf').removeClass('video audio other').css('background-image', 'none');
                        } else {
                            $('#' + event.target.name + "_btn").addClass('fill other').removeClass('video pdf audio').css('background-image', 'none');
                        }
                    }
                    fileReader.readAsDataURL(file);
                } else {
                    $("#" + fieldName).val('');
                    $scope.model.files[fieldName] = '';
                    $scope.model[fieldName] = '';
                    $scope.$apply();
                    $ionicPopup.alert({
                        title   : lang('forms.error'),
                        template: lang('forms.maximum_file_size'),
                        okText  : lang('forms.close')
                    });
                }
            } else {
                $scope.model[fieldName] = '';
                $("#" + fieldName + "_btn").removeClass('fill video pdf other audio').css('background-image', 'none');
                $("#" + fieldName + "_name").val('');
                $("#" + fieldName + "_file").val('');
                $ionicPopup.alert({
                    title   : lang('forms.error'),
                    template: lang('forms.file_not_valid'),
                    okText  : lang('forms.close')
                });
            }
        }

        $scope.submit = function (isValid) {
            if (isValid) {
                var form_data = {} ;
                Object.assign(form_data, $('.signupForm').serializeObject());
                form_data.sl = $scope.sl;
                form_data.profile_pic = $scope.model.profile_pic;
                Object.keys($scope.model.files).forEach(function (key) {
                    form_data[key] = $scope.model.files[key];
                });

                UserService.Register(form_data)
                    .success(function (result) {
                        if (result.success) {
                            showSuccess(result.payload.isactive ? lang('signup.successfully_signed_up_active_message') : lang('signup.successfully_signed_up'), 4000);
                            setTimeout(function () {
                                if (result.payload.isactive) {
                                    Auth.Login(result.payload.username, $scope.model.password, function (response) {
                                        if (response.success) {
                                            $rootScope.hideTabs = false;
                                            $rootScope.goToLandingAfterLogin();
                                            Auth.UpdateUser();
                                        }
                                    });
                                } else {
                                    if (result.payload.verification == 'by_email') {
                                        $ionicPopup.alert({
                                            title   : lang('signup.confirm_email'),
                                            template: lang('signup.email_send_successfully'),
                                            okText  : lang('signup.confirm_message'),
                                        }).then(function () {
                                            window.location.hash = signupHash;
                                        })
                                    } else if (result.payload.verification == 'by_cellphone') {
                                        Auth.username = result.payload.username;
                                        Auth.password = $scope.model.password;
                                        window.location.hash = '#/nav/widget/signup/' + result.payload.function + '/' + $widgets.data.signup.sl + '/' + result.payload.user_id;
                                    }
                                }
                            }, 4100);
                        } else {
                            $ionicPopup.show({
                                title   : lang('signup.signup_error_message'),
                                template: result.error + "<br>" + lang('signup.signup_reset_password'),
                                scope   : $scope,
                                buttons : [{
                                    text: lang('signup.cancel'),
                                    type: 'button-assertive button-clear'
                                }, {
                                    text : lang('signup.reset_password'),
                                    type : 'button-balanced button-clear',
                                    onTap: function (e) {
                                        window.location.hash = '#/nav/widget/signup/getForgetPassword/' + $widgets.data.signup.sl + '/1';
                                    }
                                }]
                            });
                        }
                    })
                    .error(function (result, statusCode) {
                        if (statusCode == -1) {
                            showWarning(lang('signup.failure_to_communicate_please_try_again'));
                        } else {
                            checkYourInternet();
                        }
                    });
            } else {
                showWarning(lang('signup.form_invalid'));
            }
        };

        $scope.validateFile = function (files) {
            if (files != null) {
                var file = files[0];
                if (window.FileReader != null && typeof file != "undefined" && typeof file.type != "undefined") {
                    if (file.size < 5 * 1024 * 1024) {
                        $timeout(function () {
                            var fileReader = new FileReader();
                            fileReader.readAsDataURL(file);
                            fileReader.onload = function (e) {
                                $timeout(function () {
                                    if (file.type.indexOf('image') > -1) {
                                        $scope.imagesets = true;
                                        $scope.model.profile_pic = e.target.result;
                                    } else {
                                        showWarning(lang('signup.the_file_type_is_not_allowed'));
                                    }
                                });
                            }
                        });
                    } else {
                        showWarning(lang('signup.maximum_authorized_volume_is_5m'));
                    }
                } else {
                    $scope.imagesets = false;
                    showWarning(lang('signup.the_file_is_not_valid'));
                }
            }
        };

        $scope.submitConfirm = function (isValid) {
            if (isValid && $scope.code != '') {
                Auth.Confirm($scope.code, $scope.userId, function (response) {
                    if (response.success) {
                        showSuccess(lang('signup.data_registration_and_activation_were_successful'), 2000);
                        $timeout(function () {
                            Auth.Login(Auth.username, Auth.password, function (response) {
                                if (response.success) {
                                    $rootScope.hideTabs = false;
                                    $rootScope.goToLandingAfterLogin();
                                    Auth.UpdateUser();
                                } else {
                                    showWarning(lang('signup.login_error_message'));
                                    window.location.hash = signupHash;
                                }
                            });
                        }, 2200);
                    } else {
                        showWarning(response.message);
                    }
                });
            } else {
                showWarning(lang('signup.verify_form_invalid'));
            }
        };

        $scope.submitLoginWithPhone = function(isValid) {
            if (isValid && $scope.code != '') {
                Auth.Login(Auth.username, $scope.code, function (response) {
                    if (response.success) {
                        $rootScope.hideTabs = false;
                        $rootScope.goToLandingAfterLogin();
                        Auth.UpdateUser();
                    } else {
                        showWarning(response.message);
                    }
                });
            } else {
                showWarning(lang('signup.form_invalid'));
            }
        };

        $scope.reSendCode = function () {
            if ($scope.time <= 5) {
                Auth.ReSendConfirm($scope.userId, function (response) {
                    if (response.success) {
                        showSuccess(lang('signup.the_code_was_sent_again'));
                        $scope.startTimer();
                    } else {
                        showWarning(response.message);
                    }
                })
            }
        }

        $scope.startTimer = function () {
            $scope.time = 90;
            $interval(function () {
                if ($scope.time > 0) {
                    $scope.time--;
                } else {
                    $interval.cancel(stop);
                }
            }, 1000);
        }

        var datevalue = false, timevalue = false;
        $scope.openDatePicker = function (model, time) {
            ionicDatePicker.openDatePicker({
                callback : function (unix, dateString) {
                    datevalue = unix;
                    $scope['model'][model] = dateString;
                    if (time) {
                        ionicTimePicker.openTimePicker({
                            callback : function (val) {
                                timevalue = val;
                                var selectedTime = typeof (val) === 'undefined' ? new Date() : new Date(val * 1000);
                                $scope['model'][model] = dateString + ' - ' + selectedTime.getUTCHours() + ':' + selectedTime.getUTCMinutes();
                            },
                            inputTime: timevalue != false ? timevalue : (new Date()).getHours() * 60 * 60,
                        });
                    }
                },
                inputDate: datevalue != false ? new Date(datevalue) : new Date(),
            });
        };

        $scope.openTimePicker = function (model) {
            ionicTimePicker.openTimePicker({
                callback : function (val) {
                    timevalue = val;
                    var selectedTime = typeof (val) === 'undefined' ? new Date() : new Date(val * 1000);
                    $scope['model'][model] = selectedTime.getUTCHours() + ':' + selectedTime.getUTCMinutes();
                },
                inputTime: timevalue != false ? timevalue : (new Date()).getHours() * 60 * 60,
            });
        };
    }

    /**
     * Login form Controller
     * @type {Controller}
     * @param {Auth} Authentication Service
     */
    LoginController.$inject = ['$scope', '$rootScope', 'Auth', '$ionicPopup', '$ionicScrollDelegate', '$timeout', '$ionicSideMenuDelegate'];

    function LoginController($scope, $rootScope, Auth, $ionicPopup, $ionicScrollDelegate, $timeout, $ionicSideMenuDelegate) {
        $timeout(function () {
            $ionicSideMenuDelegate.canDragContent(false);
            $ionicScrollDelegate.resize();
        }, 100);
        $rootScope.hideTabs = true;
        $scope.is_ios = ionic.Platform.isIOS() || !!$widgets.data.signup.single_input_login;
        $scope.codeComplete = false;
        $scope.collectCodes = function () {
            var getinputs = document.getElementsByClassName("confirm-input");
            var total = "09";
            for (var i = 0; i < 9; i++) {
                total = total + getinputs[i].value;
            }
            $scope.user.username = total;
            if (total.length == 11) {
                $scope.codeComplete = true;
            } else {
                $scope.codeComplete = false;
            }
        }

        $('.confirm-input[tabindex=1]').focus();
        $('.confirm-input[tabindex=1]').addClass('blink');

        $scope.nextInput = function (elmnt) {
            if (elmnt.which === 8) {
                if (elmnt.currentTarget.tabIndex != 1) {
                    $scope.back = elmnt.currentTarget.tabIndex;
                    $scope.back--;
                    $('.confirm-input[tabindex=' + $scope.back + ']').removeAttr('value');
                    $('.confirm-input[tabindex=' + ($scope.back + 1) + ']').removeClass('blink');
                    $('.confirm-input[tabindex=' + $scope.back + ']').addClass('blink');
                    $('.confirm-input[tabindex=' + $scope.back + ']').focus();
                    $('.confirm-input[tabindex=' + $scope.back + ']').select();
                }
            } else {
                if (elmnt.currentTarget.tabIndex != 9) {
                    $scope.next = elmnt.currentTarget.tabIndex;
                    $scope.next++;
                    $('.confirm-input[tabindex=' + ($scope.next - 1) + ']').removeClass('blink');
                    $('.confirm-input[tabindex=' + $scope.next + ']').addClass('blink');
                    $('.confirm-input[tabindex=' + $scope.next + ']').focus();
                    $('.confirm-input[tabindex=' + $scope.next + ']').select();
                } else {
                    $('.login-btn').focus();
                }
            }
        }
        $scope.focusInput = function () {
            setTimeout(function () {
                for (var i = 1; i <= 9; i++) {
                    if ($('.confirm-input[tabindex=' + i + ']').val().length == 0) {
                        $('.confirm-input[tabindex=' + i + ']').focus();
                        break;
                    } else if (i == 9) {
                        $('.confirm-input[tabindex=9]').select();
                    }
                }
            }, 100);
        }
        var showLoginWarningPopup = function (response) {
            if (response.payload.errorType == 'not_found') {
                if (response.payload.no_password) {
                    if ($scope.user.username.match('[0-9]{11}')) {
                        $rootScope.cellphone = $scope.user.username;
                    }
                    $ionicPopup.show({
                        title   : lang('signup.login_error_message'),
                        template: lang('signup.do_you_want_to_register'),
                        scope   : $scope,
                        buttons : [{
                            text: lang('signup.cancel'),
                            type: 'button-assertive button-clear'
                        }, {
                            text : lang('signup.signup'),
                            type : 'button-balanced button-clear',
                            onTap: function (e) {
                                window.location.hash = '#/nav/widget/signup/getSignup/' + $widgets.data.signup.sl + '/1';
                            }
                        }]
                    });
                } else {
                    $ionicPopup.show({
                        title   : lang('signup.login_error_message'),
                        template: lang('signup.do_you_want_to_reset_password'),
                        scope   : $scope,
                        buttons : [{
                            text: lang('signup.cancel'),
                            type: 'button-assertive button-clear'
                        }, {
                            text : lang('signup.reset_password'),
                            type : 'button-balanced button-clear',
                            onTap: function (e) {
                                window.location.hash = '#/nav/widget/signup/getForgetPassword/' + $widgets.data.signup.sl + '/1';
                            }
                        }]
                    });
                }
            } else {
                $ionicPopup.alert({
                    title   : lang('signup.error_in_login'),
                    template: response.message,
                    okText  : lang('signup.close')
                });
                if (response.payload.errorType == 'user_not_active') {
                    setTimeout(function () {
                        if (response.payload.verification === 'by_email') {
                            $ionicPopup.alert({
                                title   : lang('signup.confirm_email'),
                                template: lang('signup.email_send_successfully'),
                                okText  : lang('signup.confirm_message'),
                            }).then(function () {
                                window.location.hash = signupHash;
                            });
                        } else if (response.payload.verification === 'by_cellphone') {
                            Auth.username = $scope.user.username;
                            Auth.password = $scope.user.password;
                            window.location.hash = '#/nav/widget/signup/confirmCellphone/' + $widgets.data.signup.sl + '/' + response.payload.user_id;
                        }
                    }, 2100);
                    return;
                }
            }
        };
        $scope.submit = function (isValid) {
            if (isValid) {
                startSMSWatch();
                Auth.Login($scope.user.username, $scope.user.password, function (response) {
                    if (response.success) {
                        $rootScope.hideTabs = false;
                        $rootScope.goToLandingAfterLogin();
                        Auth.UpdateUser();
                        $ionicSideMenuDelegate.canDragContent(true);
                    } else if (response.payload.no_password && response.payload.errorType !== 'not_found') {
                        Auth.username = $scope.user.username;
                        window.location.hash = '#/nav/widget/signup/loginWithPhone/' + $widgets.data.signup.sl + '/' + response.payload.user_id;
                    } else {
                        showLoginWarningPopup(response);
                    }
                });
            } else {
                showWarning(lang('signup.form_invalid'));
            }
        };

        $scope.forget_password = function (isValid) {
            if (isValid) {
                Auth.ForgetPassword($scope.user_identity, function (response) {
                    if (response.success) {
                        $ionicPopup.alert({
                            title   : '',
                            template: response.message,
                            buttons : [{
                                text: lang('signup.confirm_message'),
                                type: 'button-default'
                            }]
                        });
                        window.location.hash = signupHash;
                    }
                });
            } else {
                showWarning(lang('signup.form_invalid'));
            }
        }

        function startSMSWatch() {
            if(typeof cordova !== "undefined" && cordova.plugins && cordova.plugins.SMSRetriever) {
                cordova.plugins.SMSRetriever.startWatch()
            }
        }
        if(typeof cordova !== "undefined" && cordova.plugins && cordova.plugins.SMSRetriever) {
            cordova.plugins.SMSRetriever.getHashString(function(strHash){
                $app_data.sms_hash = strHash;
            });
        }


    }

    /**
     * Tickets Controller
     * ticket list view controller
     */
    ticketsController.$inject = ['$scope', '$rootScope', '$ionicPopup', '$http'];

    function ticketsController($scope, $rootScope, $ionicPopup, $http) {
        var vm = this;
        vm.loadMore = loadMore;
        vm.refresh = refresh;
        vm.search = search;
        vm.markAllMessagesAsReadAlert = markAllMessagesAsReadAlert;
        vm.noMoreItemsAvailable = true;
        vm.infiniteScrollLoading = false;
        vm.message = '';
        var length = 20;

        $scope.$watch('sl', function () {
            getTickets();
        });

        
        function getTickets() {
            $http.post(url + '/api/v1/widget/post/signup/getTickets', {
                sl    : $scope.sl,
                length: length
            })
                .success(function (result) {
                    if (result.success) {
                        vm.tickets = result.payload.tickets;
                        vm.message = result.message;
                        if (result.payload.tickets.length == length) {
                            vm.noMoreItemsAvailable = false;
                        }
                    }
                    $scope.$broadcast('scroll.refreshComplete');
                })
                .error(function () {
                    checkYourInternet();
                    $scope.$broadcast('scroll.refreshComplete');
                });
        }

        function markAllMessagesAsReadAlert() {
            $ionicPopup.alert({
                title   : lang('signup.are_you_sure'),
                template: lang('signup.clear_count_message'),
                buttons : [{
                    text : '<b>تایید</b>',
                    type : 'button-assertive',
                    onTap: function () {
                        markAllMessagesAsRead();
                    }
                }, {
                    text: 'بستن',
                    type: 'button-stable'
                }]
            });
        }
        function markAllMessagesAsRead() {
            $http.post(url + '/api/v1/widget/post/signup/markAllMessagesAsRead', {
                sl    : $scope.sl,
            })
            .success(function (result) {
                if (result.success) {
                    getTickets();
                    $rootScope.user.unread_tickets_count = 0; 
                }
            })
            .error(function () {
                checkYourInternet();
            });
        }

        function refresh() {
            getTickets();
        }

        function search() {
            $http.post(url + '/api/v1/widget/post/signup/getTickets', {
                sl    : $scope.sl,
                q     : vm.searchText,
                length: 100
            })
                .success(function (result) {
                    if (result.success) {
                        vm.tickets = result.payload.tickets;
                        vm.message = result.message;
                    } else {
                        showWarning(result.message);
                    }
                })
                .error(function () {
                    checkYourInternet();
                });
        }

        function loadMore() {
            if (!vm.noMoreItemsAvailable) {
                vm.noMoreItemsAvailable = true;
                var start = vm.tickets.length;
                if (isOnline()) {
                    vm.infiniteScrollLoading = true;
                    var data = {
                        sl    : $scope.sl,
                        start : start,
                        length: length
                    };
                    $http({
                        method   : 'POST',
                        noLoading: true,
                        url      : url + '/api/v1/widget/post/signup/getTickets',
                        data     : data
                    })
                        .success(function (result) {
                            if (result.success) {
                                for (var i = 0; i < result.payload.tickets.length; i++) {
                                    vm.tickets.push(result.payload.tickets[i]);
                                }
                                vm.noMoreItemsAvailable = result.payload.tickets.length < length;
                            }
                            vm.infiniteScrollLoading = false;
                            $scope.$broadcast('scroll.infiniteScrollComplete');
                        })
                        .error(function () {
                            console.error('ERR', err.status);
                            vm.infiniteScrollLoading = false;
                            $scope.$broadcast('scroll.infiniteScrollComplete');
                        });
                }
            } else {
                return;
            }
        }
    }


    /**
     * Ticket Controller
     * single ticket view Controller
     */
    ticketController.$inject = ['$scope', '$rootScope', '$http'];

    function ticketController($scope, $rootScope, $http) {
        var vm = this;
        vm.ticket = {};
        vm.sendTicket = sendTicket;
        vm.usertickets = [];

        // on init
        $scope.$watch('ticket_id', function () {
            if ($scope.ticket_id) {
                $rootScope['ticket' + $scope.ticket_id] = 'visited';
                $rootScope.user.unread_tickets_count -= $scope.unread_ticket_count;
                $rootScope.user.unread_tickets_count = Math.max($rootScope.user.unread_tickets_count == undefined ? 0 : $rootScope.user.unread_tickets_count, 0);
            }
        });

        function sendTicket(valid) {
            if (valid) {
                var fd = new FormData();
                for (var key in vm.ticket) {
                    fd.append(key, vm.ticket[key]);
                }
                fd.append('sl', $scope.sl);
                fd.append('authToken', $rootScope.user.token);

                $http.post(url + '/api/v1/widget/post/signup/postTicket', fd, {
                    withCreadential : true,
                    headers         : {
                        'Content-Type': undefined,
                    },
                    transformRequest: angular.identity
                })
                    .success(function (result) {
                        if (result.success) {
                            vm.ticket = {
                                title  : '',
                                content: '',
                                attach : ''
                            };
                            vm.usertickets.push(result.payload.ticket);
                            if (typeof result.payload.sl != "undefined")
                                $scope.sl = result.payload.sl;
                            showToast(lang('signup.your_message_has_been_successfully_recorded'));
                        } else {
                            showToast(result.message);
                        }
                    })
                    .error(function () {
                        showToast(lang('signup.failure_to_communicate_please_try_again'));
                    });
            } else {
                showToast(lang('signup.form_invalid'));
                return;
            }
        }
    }

    ticketViewController.$inject = ['$scope', '$rootScope', '$http'];
    function ticketViewController($scope, $rootScope, $http) {
        var vm = this;
        vm.ticket = {};
        vm.sendTicket = sendTicket;
        vm.refresh = refresh;
        vm.usertickets = [];
        vm.ticket_closed = true;

        // on init
        $scope.$watch('ticket_id', function () {
            if ($scope.ticket_id) {
                $rootScope['ticket' + $scope.ticket_id] = 'visited';
                updateUnreadTicketCount();
            }
            getTicket();
        });

        function updateUnreadTicketCount() {
            if (!!$scope.unread_ticket_count) {
                $rootScope.user.unread_tickets_count -= $scope.unread_ticket_count;
                $rootScope.user.unread_tickets_count = Math.max($rootScope.user.unread_tickets_count == undefined ? 0 : $rootScope.user.unread_tickets_count, 0);
            }
        }

        function getTicket() {
            $http.get(url + '/api/v1/widget/route/signup/getTicketJson/' + $scope.sl + '/' + $scope.ticket_id)
            .success(function (result) {
                if (result.success) {
                    vm.tickets = result.payload.tickets;
                    vm.ticket_closed = result.payload.ticket_closed;
                    $scope.unread_ticket_count = result.payload.unread_ticket_count;
                    updateUnreadTicketCount();
                }
                $scope.$broadcast('scroll.refreshComplete');
            })
            .error(function () {
                checkYourInternet();
                $scope.$broadcast('scroll.refreshComplete');
            });
        }

        function refresh() {
            getTicket();
        }

        function sendTicket(valid) {
            if (valid) {
                var fd = new FormData();
                for (var key in vm.ticket) {
                    fd.append(key, vm.ticket[key]);
                }
                fd.append('sl', $scope.sl);
                fd.append('authToken', $rootScope.user.token);

                $http.post(url + '/api/v1/widget/post/signup/postTicket', fd, {
                        withCreadential: true,
                        headers: {
                            'Content-Type': undefined,
                        },
                        transformRequest: angular.identity
                    })
                    .success(function (result) {
                        if (result.success) {
                            vm.ticket = {
                                title: '',
                                content: '',
                                attach: ''
                            };
                            getTicket();
                            if (typeof result.payload.sl != "undefined")
                                $scope.sl = result.payload.sl;
                            showToast(lang('signup.your_message_has_been_successfully_recorded'));
                        } else {
                            showToast(result.message);
                        }
                    })
                    .error(function () {
                        showToast(lang('signup.failure_to_communicate_please_try_again'));
                    });
            } else {
                showToast(lang('signup.form_invalid'));
                return;
            }
        }
    }

    /**
     * service for make http call for login and Logut
     * @type {factory}
     * @param {UserService} UserService : keeps user data
     * @return {object} AuthenticationService
     */
    AuthenticationService.$inject = ['$rootScope', '$http', '$timeout', 'localStorage', 'UserService'];

    function AuthenticationService($rootScope, $http, $timeout, localStorage, UserService) {
        var Auth = {};
        Auth.username = '';
        Auth.password = '';
        Auth.User = {isLogin: false, accessible_pages: default_access_page};
        Auth.Login = Login;
        Auth.Check = Check;
        Auth.Logout = Logout;
        Auth.CanAccess = CanAccess;
        Auth.SetCredentials = SetCredentials;
        Auth.Update = Update;
        Auth.Confirm = Confirm;
        Auth.ReSendConfirm = ReSendConfirm;
        Auth.ForgetPassword = ForgetPassword;
        Auth.ChangePassword = ChangePassword;
        Auth.UpdateUser = UpdateUser;
        Auth.init = init;
        Auth.Delete = Delete;

        (function () {
            Auth.init();
            document.addEventListener("online", function () {
                $timeout(function () {
                    UpdateUser();
                }, 500);
            });
        })();

        return Auth;

        function init() {
            Auth.User = localStorage.all('user');
            $rootScope.user = Auth.User;
            if (Auth.User.isLogin) {
                $http.defaults.headers.common['X-auth-token'] = Auth.User.token;
                $.ajaxSetup({
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader('X-auth-token', Auth.User.token);
                    }
                });
                $timeout(function () {
                    UpdateUser();
                }, 500);
            } else {
                Auth.User.isLogin = false;
                Auth.User.accessible_pages = default_access_page;
                $timeout(function () {
                    UserService.UpdateDefaultAccessPage().success(function (result) {
                        if (result.success) {
                            Auth.User.accessible_pages = result.payload.accessible_pages;
                        }
                    });
                    if (typeof window.pushpole !== 'undefined') {
                        window.pushpole.isPushPoleInitialized(function (r) {
                            if (r && typeof Auth.User.role_id == 'undefined') {
                                window.pushpole.subscribe('signup_role_1');
                            }
                        });
                    }
                    if (typeof window.FirebasePlugin !== 'undefined') {
                        window.FirebasePlugin.setAutoInitEnabled(function (r) {
                            if (r && typeof Auth.User.role_id == 'undefined') {
                                window.FirebasePlugin.subscribe('signup_role_1', function () {
                                    console.log("Subscribed to topic", true);
                                }, function (error) {
                                    console.log("Failed to subscribe to topic", error, true);
                                });
                            }
                        });
                    }
                }, 2000);
            }

            if ($widgets.data.signup.hasHeaderTicketLink) {
                if (typeof $rootScope.navButtons == "undefined") {
                    $rootScope.navButtons = {};
                }
                setTimeout(function () {
                    $rootScope.navButtons.signup = {
                        title: lang('signup.inbox'),
                        icon : 'ion-email' + ($rootScope.user.unread_tickets_count ? ' shake' : ''),
                        href : '#/nav/widget/signup/getTicketList/' + $widgets.data.signup.sl + '/1',
                        badge: $rootScope.user.unread_tickets_count_display,
                        show : Auth.User.isLogin
                    };
                    $rootScope.$watch('user.unread_tickets_count', function (newValue, oldValue) {
                        $rootScope.navButtons.signup.badge = parseInt(newValue) > 99 ? '+99' : newValue;
                        $rootScope.navButtons.signup.icon = parseInt(newValue) > 0 ? 'ion-email shake' : 'ion-email';
                    }, true);
                    $rootScope.$watch('user.isLogin', function (newValue, oldValue) {
                        $rootScope.navButtons.signup.show = newValue;
                    }, true);
                }, 500);
            }

            $rootScope.$watch('user.unread_tickets_count', function (newValue, oldValue) {
                $rootScope.user.unread_tickets_count_display = parseInt(newValue) > 99 ? '+99' : newValue;
            }, true);
        }

        function UpdateUser() {
            var oldRoleId = null;
            if (Auth.User.isLogin && typeof Auth.User.role_id !== 'undefined') {
                oldRoleId = Auth.User.role_id;
            }
            UserService.UpdateUserInfo().success(function (result) {
                if (result.success) {
                    Auth.SetCredentials(result.payload.user, result.payload.token);
                    //todo: refactor : move this logic to pushpole widget
                    if (typeof window.pushpole !== 'undefined') {
                        window.pushpole.isPushPoleInitialized(function (r) {
                            if (r && oldRoleId && oldRoleId != result.payload.user.role_id) {
                                console.log('unsubscribe signup_role_' + oldRoleId);
                                window.pushpole.unsubscribe('signup_role_' + oldRoleId);
                            }
                            console.log('subscribe to signup_role_' + result.payload.user.role_id);
                            window.pushpole.subscribe('signup_role_' + result.payload.user.role_id);
                            window.pushpole.subscribe('registered');
                            window.pushpole.unsubscribe('signup_role_1');
                            if (window.pushe && window.pushe.setCustomId) {
                                window.pushe.setCustomId('user_' + result.payload.user.id);
                            }
                        });
                    }

                    //todo: refactor : move this logic to Firebase widget
                    if (typeof window.FirebasePlugin !== 'undefined') {
                        window.FirebasePlugin.isAutoInitEnabled(function (r) {
                            if (r && oldRoleId && oldRoleId != result.payload.user.role_id) {
                                console.log('unsubscribe signup_role_' + oldRoleId);
                                window.FirebasePlugin.unsubscribe('signup_role_' + Auth.User.role_id, function () {
                                    console.log("Unsubscribed from topic");
                                }, function (error) {
                                    console.log("Failed to unsubscribe from topic", error);
                                });
                            }
                            console.log('subscribe to signup_role_' + result.payload.user.role_id);
                            window.FirebasePlugin.subscribe('signup_role_' + result.payload.user.role_id, function () {
                                console.log("Subscribed to topic", true);
                            }, function (error) {
                                console.log("Failed to subscribe to topic", error, true);
                            });
                            window.FirebasePlugin.subscribe('registered', function () {
                                console.log("Subscribed to topic", true);
                            }, function (error) {
                                console.log("Failed to subscribe to topic", error, true);
                            });
                            window.FirebasePlugin.unsubscribe('signup_role_1', function () {
                                console.log("Unsubscribed from topic");
                            }, function (error) {
                                console.log("Failed to unsubscribe from topic", error);
                            });
                            if (window.FirebasePlugin && window.FirebasePlugin.setUserId) {
                                window.FirebasePlugin.setUserId('user_' + result.payload.user.id);
                            }
                        });
                    }
                    if (Boolean(result.payload.showAd) === false) {
                        $show_ad = false;
                        var removeAd = new Event('removeAd');
                        document.dispatchEvent(removeAd);
                    }
                } else {
                    if (typeof result !== 'undefined'
                        && typeof result.payload !== 'undefined'
                        && typeof result.payload.shouldLogout !== 'undefined'
                        && result.payload.shouldLogout) {
                        Auth.Logout();
                    }
                }
            });
        }

        function Login(username, password, callback) {
            var response;
            UserService.LoginWithUsername(username, password)
                .success(function (result) {
                    if (result.success) {
                        if (typeof window.pushpole !== 'undefined') {
                            console.log("pushe");
                            window.pushpole.isPushPoleInitialized(function (r) {
                                console.log('is inited?');
                                if (r) {
                                    console.log('subscribe to signup_role_' + result.payload.user.role_id);
                                    window.pushpole.subscribe('signup_role_' + result.payload.user.role_id);
                                }
                            });
                        }
                        if (typeof window.FirebasePlugin !== 'undefined') {
                            console.log("firebase");
                            window.FirebasePlugin.isAutoInitEnabled(function (r) {
                                console.log('is inited');
                                if (r) {
                                    console.log('subscribe to signup_role_' + result.payload.user.role_id);
                                    window.FirebasePlugin.subscribe('signup_role_' + result.payload.user.role_id, function () {
                                        console.log("Subscribed to topic", true);
                                    }, function (error) {
                                        console.log("Failed to subscribe to topic", error, true);
                                    });
                                }
                            });
                        }
                        window.localStorage.device_id = result.payload.device_id;
                        phone_id = result.payload.device_id;
                        Auth.SetCredentials(result.payload.user, result.payload.token);
                        response = {success: true};
                    } else {
                        response = {
                            success: false,
                            message: result.error,
                            payload: result.payload
                        };
                    }
                    callback(response);
                })
                .error(function (result) {
                    callback({success: false, message: lang('signup.failure_to_communicate_please_try_again')});
                    console.error(result);
                });
        }

        function Check() {
            return Auth.User.isLogin;
        }

        function CanAccess(pageid) {
            if (Auth.User.accessible_pages == null) {
                return true;
            }
            return (
                    typeof pageid !== 'undefined') &&
                (Auth.User.accessible_pages.includes(Number(pageid)) || (Auth.User.accessible_pages.includes(String(pageid)))
                );
        }

        function Logout() {
            UserService.Logout();
            Auth.User.isLogin = false;
            Auth.User.token = '';
            Auth.User.accessible_pages = default_access_page;
            localStorage.save(Auth.User, 'user');
            if (typeof window.pushpole !== 'undefined') {
                window.pushpole.isPushPoleInitialized(function (r) {
                    if (r) {
                        window.pushpole.unsubscribe('signup_role_' + Auth.User.role_id);
                    }
                });
            }
            if (typeof window.FirebasePlugin !== 'undefined') {
                window.FirebasePlugin.isAutoInitEnabled(function (r) {
                    if (r) {
                        window.FirebasePlugin.unsubscribe('signup_role_' + Auth.User.role_id, function () {
                            console.log("Unsubscribed from topic");
                        }, function (error) {
                            console.log("Failed to unsubscribe from topic", error);
                        });
                    }
                });
            }
        }

        function SetCredentials(user, token) {
            Auth.User = user;
            Auth.User.isLogin = true;
            Auth.User.token = token;
            $rootScope.user = Auth.User;
            $http.defaults.headers.common['X-auth-token'] = token;
            $.ajaxSetup({
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('X-auth-token', token);
                }
            });
            if (user.homePageSlug) {
                homeHash = '#/nav/' + user.homePageSlug;
                homeState = 'nav.' + user.homePageSlug;
            }
            localStorage.save(Auth.User, 'user');
            $rootScope.$broadcast('signup.user.updated', user);
        }

        function Update(user, callback) {
            var response;
            UserService.Update(user)
                .success(function (result) {
                    result.payload = typeof result.payload === 'undefined' ? [] : result.payload;
                    if (result.success) {
                        Auth.SetCredentials(result.payload.user, result.payload.token);
                        response = {success: true, payload: result.payload};
                    } else {
                        response = {success: false, message: result.error, payload: result.payload};
                    }
                    callback(response);
                })
                .error(function (result, statusCode) {
                    result.payload = typeof result.payload === 'undefined' ? [] : result.payload;
                    var message = statusCode == -1 ? lang('signup.error_in_sending_information') : lang('signup.error_in_updating');
                    callback({success: false, message: message, payload: result.payload});
                });
        }

        function Confirm(code, user_id, callback) {
            var response;
            UserService.ConfirmCellphone(code, user_id)
                .success(function (result) {
                    if (result.success) {
                        response = {success: true};
                    } else {
                        response = {success: false, message: result.error};
                    }
                    callback(response);
                })
                .error(function () {
                    callback({success: false, message: lang('signup.error_in_sending_information')});
                });
        }

        function ReSendConfirm(user_id, callback) {
            var response;
            UserService.resendconfirmcode(user_id)
                .success(function (result) {
                    if (result.success) {
                        response = {success: true};
                    } else {
                        response = {success: false, message: result.error};
                    }
                    callback(response);
                })
                .error(function () {
                    callback({success: false, message: lang('signup.error_in_sending_information')});
                });
        }

        function ForgetPassword(user_id, callback) {
            var response;
            UserService.ForgetPassword(user_id)
                .success(function (result) {
                    if (result.success) {
                        response = {success: true, message: result.payload.message};
                    }
                    callback(response);
                })
                .error(function () {
                    checkYourInternet();
                    callback({success: false, message: lang('signup.error_in_sending_information')});
                });
        }

        function ChangePassword(oldPass, newPass, callback) {
            var response;
            UserService.ChangePassword(oldPass, newPass)
                .success(function (result) {
                    if (result.success) {
                        response = {success: true};
                    } else {
                        response = {success: false, message: result.error};
                    }
                    callback(response);
                })
                .error(function (result) {
                    callback({success: false, message: lang('signup.error_in_sending_information')});
                });
        }

        function Delete(callback) {
            var response;
            UserService.Delete()
                .success(function (result) {
                    if (result.success) {
                        response = {success: true};
                    } else {
                        response = {success: false, message: result.error};
                    }
                    callback(response);
                })
                .error(function (result) {
                    callback({success: false, message: lang('signup.error_in_sending_information')});
                });
        }
    }

    /**
     * service for make API call to users api
     * @type {factory}
     * @param {$http}
     * @return {object} UserService
     */
    UserService.$inject = ['$http'];

    function UserService($http) {
        var service = {};

        service.LoginWithUsername = LoginWithUsername;
        service.Register = Register;
        service.Update = Update;
        service.ConfirmCellphone = ConfirmCellphone;
        service.resendconfirmcode = resendconfirmcode;
        service.UpdateUserInfo = UpdateUserInfo;
        service.Logout = Logout;
        service.ForgetPassword = ForgetPassword;
        service.ChangePassword = ChangePassword;
        service.UpdateDefaultAccessPage = UpdateDefaultAccessPage;
        service.Delete = Delete;

        return service;

        function LoginWithUsername(username, password) {
            return $http.post(url + '/api/v1/widget/post/signup/Login', {
                username: username,
                password: password,
                phone_id: phone_id,
                sl      : $widgets.data.signup.sl,
                app_data: $app_data, // define global in main app js
                device  : $device_info
            });
        }

        function Register(user) {
            return $http.post(url + '/api/v1/widget/post/signup/register', user);
        }

        function Update(user) {
            return $http.post(url + '/api/v1/widget/post/signup/editUser', user);
        }

        function ConfirmCellphone(code, user_id) {
            return $http.post(url + '/api/v1/widget/post/signup/confirmByCellphone', {
                code   : code,
                user_id: user_id,
                sl     : $widgets.data.signup.sl
            });
        }

        function resendconfirmcode(user_id) {
            return $http.post(url + '/api/v1/widget/post/signup/resendConfirmCodeToCellphone', {
                user_id: user_id,
                sl     : $widgets.data.signup.sl,
                app_data: $app_data, // define global in main app js
                device  : $device_info
            });
        }

        function UpdateUserInfo() {
            return $http.post(url + '/api/v1/widget/post/signup/updateUserInfo', {
                sl      : $widgets.data.signup.sl,
                app_data: $app_data, // define global in main app js
                device  : $device_info
            }, {
                noLoading: true
            });
        }

        function Logout() {
            return $http.post(url + '/api/v1/widget/post/signup/logout', {
                sl: $widgets.data.signup.sl
            }, {
                noLoading: true
            });
        }

        function ForgetPassword(user_id) {
            return $http.post(url + '/api/v1/widget/post/signup/resetPassword', {
                sl           : $widgets.data.signup.sl,
                user_identity: user_id
            });
        }

        function ChangePassword(oldPass, newPass) {
            return $http.post(url + '/api/v1/widget/post/signup/changePassword', {
                sl          : $widgets.data.signup.sl,
                old_password: oldPass,
                new_password: newPass
            });
        }

        function UpdateDefaultAccessPage() {
            return $http.post(url + '/api/v1/widget/post/signup/updateDefaultAccessPage', {
                sl: $widgets.data.signup.sl
            }, {
                noLoading: true
            });
        }

        function Delete() {
            return $http.post(url + '/api/v1/widget/post/signup/deleteAccount', {
                sl: $widgets.data.signup.sl
            });
        }
    }

    /**
     * filter to convert conditional values to miningfull string
     * @type {filter}
     * @param {string} string string to convert
     * @return {function} filter
     */
    function fixConditionalValueFilter() {
        return function fixConditionalValue(string, type) {
            if (typeof type == 'undefined') type = 'string';
            if (Array.isArray(string) || typeof string == 'undefined') {
                return string;
            }
            var originalString = string.toString();
            try {
                string = string.toLowerCase();
            } catch (e) {
                string = '';
            }

            if (type == 'checkbox') {
                return (
                    string == 'on' ||
                    string == 'true' ||
                    string == '1'
                ) ? lang('signup.yes_message') :
                    (
                        string == 'off' ||
                        string == 'false' ||
                        string == '0'
                    ) ? lang('signup.no_message') : originalString;
            }

            return originalString;
        };
    }

    /**
     * filter to join array data as string with giving prop
     * @type {filter}
     * @param {array} array string or array to convert
     * @param {sprator} string sprator sign
     * @param {prop} string prop of array to show
     * @return {function} filter
     */
    function joinFilter() {
        return function join(array, separator, prop) {
            if (!Array.isArray(array)) {
                return array; // if not array return original
            }

            return (!angular.isUndefined(prop) ? array.map(function (item) {
                return item[prop];
            }) : array).join(separator);
        };
    }

})();

try {
    if (phone_id == "" && localStorage.device_id) {
        phone_id = localStorage.device_id;
    }
} catch (error) {
}

if ($app_data.target_market !== 'googleplay') {
    document.addEventListener("deviceready", function () {
        phone_id = device.uuid;
    });
}

$.fn.serializeObject = function () {
    var o = {};
    var a = this.serializeArray();
    // console.log(a);
    $.each(a, function () {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};

$widgets.functions.signup = {
    showWalletPaymentError: function (message, title, redirectPageLink, okText) {
        angular.element($('ion-view')).injector().get("$ionicPopup").confirm({
            cssClass  : 'signup_pupop',
            title     : typeof title !== "undefined" ? title : lang('signup.not_enough_credits'),
            template  : typeof message !== "undefined" ? message : lang('signup.wallet_payment_error_message'),
            okText    : typeof okText !== "undefined" ? okText : lang('signup.increase_balance'),
            okType    : 'button-clear button-balanced',
            cancelText: lang('signup.close'),
            cancelType: 'button-clear button-assertive',
        }).then(function (confirm) {
            if (confirm) {
                if (typeof redirectPageLink !== "undefined") {
                    window.location.hash = redirectPageLink;
                } else {
                    window.location.hash = $widgets.data.signup.wallet_link;
                }
            }
        });
    },
    updateUser            : function () {
        angular.element($('ion-view')).injector().get("Auth").UpdateUser();
    }
};
