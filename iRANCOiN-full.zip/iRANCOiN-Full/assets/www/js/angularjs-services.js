angular.module('ngApp.services', [])
    /**
     * services for storage object as json in window.localstorage
     * @type {factory service}
     */
    .factory('localStorage', function () {
        return {
            all: function (key, defaultValue) {
                var data = window.localStorage[key];
                if (data) {
                    return angular.fromJson(data);
                }
                if (typeof defaultValue !== "undefined") {
                    return defaultValue;
                }
                return {};
            },
            save: function (data, key) {
                window.localStorage[key] = angular.toJson(data);
            },
            clear: function (key) {
                window.localStorage.removeItem(key);
            },
            get: function (key, id) {
                var data = window.localStorage[key];
                if (data) {
                    data = angular.fromJson(data);
                    return data[id];
                }
                return {};
            },
            add: function (data, key) {
                var old_data = window.localStorage[key];
                if (old_data) {
                    old_data = angular.fromJson(old_data);
                    data = angular.merge(old_data, data);
                }
                window.localStorage[key] = angular.toJson(data);
            },
            addnew: function (data, key) {
                var storage = window.localStorage[key];
                if (storage) {
                    storage = angular.fromJson(storage);
                } else {
                    storage = [];
                }
                storage.push(data);
                window.localStorage[key] = angular.toJson(storage);
            },
            remove: function (key, id) {
                var storage = window.localStorage[key];
                if (storage) {
                    storage = angular.fromJson(storage);
                    delete storage[id];
                    window.localStorage[key] = angular.toJson(storage);
                }
            }
        }
    })
    /**
     * services to convert gregorian string date to persian date array
     * @type {factory service}
     */
    .factory('gregorianToJulian', function () {
        function mod(a, b) {
            return a - ~~(a / b) * b
        }

        function leapGregorian(year) {
            return ((year % 4) === 0) &&
                (!(((year % 100) === 0) && ((year % 400) !== 0)));
        }

        // GREGORIAN_TO_JD  --  Determine Julian day number from Gregorian calendar date
        function gregorianToJulian(year, month, day) {
            var pad;
            if (month <= 2) {
                pad = 0;
            } else if (leapGregorian(year)) {
                pad = -1;
            } else {
                pad = -2;
            }

            return (1721425.5 - 1) +
                (365 * (year - 1)) +
                Math.floor((year - 1) / 4) +
                (-Math.floor((year - 1) / 100)) +
                Math.floor((year - 1) / 400) +
                Math.floor((((367 * month) - 362) / 12) + (pad + day));
        }

        function persianToJulian(year, month, day) {
            var epbase = year - ((year >= 0) ? 474 : 473);
            var epyear = 474 + mod(epbase, 2820);

            return day +
                ((month <= 7) ?
                    ((month - 1) * 31) :
                    (((month - 1) * 30) + 6)
                ) +
                Math.floor(((epyear * 682) - 110) / 2816) +
                ((epyear - 1) * 365) +
                (Math.floor(epbase / 2820) * 1029983) + (1948320.5 - 1);
        }

        function julianToPersian(jd) {
            var njd = Math.floor(jd) + 0.5;
            var depoch = njd - persianToJulian(475, 1, 1);
            var cycle = Math.floor(depoch / 1029983);
            var cyear = mod(depoch, 1029983);
            var ycycle;
            if (cyear === 1029982) {
                ycycle = 2820;
            } else {
                var aux1 = Math.floor(cyear / 366);
                var aux2 = mod(cyear, 366);
                ycycle = Math.floor(((2134 * aux1) + (2816 * aux2) + 2815) / 1028522) +
                    aux1 + 1;
            }
            var year = ycycle + (2820 * cycle) + 474;
            if (year <= 0) {
                year -= 1;
            }
            var yday = (njd - persianToJulian(year, 1, 1)) + 1;
            var month = (yday <= 186) ? Math.ceil(yday / 31) : Math.ceil((yday - 6) / 30);
            var day = (njd - persianToJulian(year, month, 1)) + 1;

            return [year, month, day];
        }

        /**
         * Convert gregorian date To persian julian
         *
         * The functionality is based on great library https://github.com/arashm/JDate
         *
         * @param {dateString} dateString
         */
        return function (dateString) {
            var date = new Date(dateString);
            return julianToPersian(gregorianToJulian(date.getUTCFullYear(), date.getUTCMonth() + 1, date.getUTCDate()));
        }
    })
    /**
     * cordovaGeolocation factory
     * inhert from ngCordova project
    */
    .factory('$cordovaGeolocation', ['$q', function ($q) {
        return {
            getCurrentPosition: function (options) {
                var q = $q.defer();

                navigator.geolocation.getCurrentPosition(function (result) {
                    q.resolve(result);
                }, function (err) {
                    q.reject(err);
                }, options);

                return q.promise;
            },

            watchPosition: function (options) {
                var q = $q.defer();

                var watchID = navigator.geolocation.watchPosition(function (result) {
                    q.notify(result);
                }, function (err) {
                    q.reject(err);
                }, options);

                q.promise.cancel = function () {
                    navigator.geolocation.clearWatch(watchID);
                };

                q.promise.clearWatch = function (id) {
                    navigator.geolocation.clearWatch(id || watchID);
                };

                q.promise.watchID = watchID;

                return q.promise;
            },

            clearWatch: function (watchID) {
                return navigator.geolocation.clearWatch(watchID);
            }
        };
    }])
    /**
     * conver string to standard date format for ng-model in input type date
     * @type {directive}
     * @return {intiger} standard date format
     */
    .directive('stringToDate', function () {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, element, attrs, ngModel) {
                ngModel.$parsers.push(function (value) {
                    return '' + value;
                });
                ngModel.$formatters.push(function (date) {
                    return new Date(date);
                });
            }
        }
    })
    /**
     * String to number for ng-model in number input
     * @type {directive}
     * @return {intiger} standard number format
     */
    .directive('stringToNumber', function () {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, element, attrs, ngModel) {
                ngModel.$parsers.push(function (value) {
                    return '' + value;
                });
                ngModel.$formatters.push(function (value) {
                    return parseFloat(value);
                });
            }
        };
    })
    /**
     * String to time for ng-model in time input
     * @type {directive}
     * @return {time} standard time format
     */
    .directive('stringToTime', function () {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, element, attrs, ngModel) {
                ngModel.$parsers.push(function (value) {
                    return '' + value;
                });
                ngModel.$formatters.push(function (value) {
                    if (!!!value) {
                        return;
                    }
                    value = value.split(':');
                    if (value[2] == undefined) {
                        value[2] = '00';
                    }
                    return new Date(1970, 0, 1, value[0], value[1], value[2]);
                });
            }
        };
    })
    /**
     * String to time for ng-model in time input
     * @type {directive}
     * @return {time} standard time format
     */
    .directive('stringToBoolean', function () {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, element, attrs, ngModel) {
                ngModel.$parsers.push(function (value) {
                    return '' + value;
                });
                ngModel.$formatters.push(function (value) {
                    return value == '1' || value == 'true';
                });
            }
        };
    })
    .directive('backButton', function () {
        return {
            restrict: 'E',
            replace: true,
            controller: function ($scope, $ionicHistory) {
                $scope.canGoBack = false;
                if ($ionicHistory.backView()) {
                    $scope.canGoBack = true;
                }
                $scope.goBack = function () {
                    $ionicHistory.goBack();
                }
            },
            template: [
                '<button class="button back-buttonx buttons button-clear" ng-show="canGoBack" ng-click="goBack()">',
                '<i class="icon ion-arrow-left-c"></i>',
                '</button>',
            ].join('')
        };
    })
    .directive('hideTabs', function ($rootScope) {
        return {
            restrict: 'A',
            link: function ($scope, $el) {
                $rootScope.hideTabs = 'tabs-item-hide';
                $scope.$on('$destroy', function () {
                    $rootScope.hideTabs = '';
                });
            }
        };
    })
    .directive('initBind', function ($compile) {
        return {
            restrict: 'A',
            link: function (scope, element, attr) {
                attr.$observe('ngBindHtml', function () {
                    if (attr.ngBindHtml) {
                        $compile(element[0].children)(scope);
                    }
                })
            }
        };
    })
    .directive('noItem', function () {
        return {
            restrict: 'E',
            template: function (elem, attr) {
                return (
                    '<div style="color: #b2b2b2; display: flex; felx: 1; justify-content: center;"><i style="margin-left: 5px; font-size: 17px;" class="icon ion-android-sad"></i>' + attr.message + '</div>'
                );
            }
        }
    })
    .directive('focusMe', function ($timeout) {
        return {
            link: function (scope, element, attrs) {

                $timeout(function () {
                    element[0].focus();
                }, 750);
            }
        };
    })
    .directive("horizontalScrollFix", ["$timeout", "$ionicScrollDelegate", function ($timeout, $ionicScrollDelegate) {
        return {
            restrict: "A",
            link: function (scope, element, attrs) {
                var sv = $ionicScrollDelegate.$getByHandle(attrs.delegateHandle).getScrollView();
                var container = sv.__container;
                var originaltouchStart = sv.touchStart;
                var originalmouseDown = sv.mouseDown;
                var originaltouchMove = sv.touchMove;
                var originalmouseMove = sv.mouseMove;
                container.removeEventListener('touchstart', sv.touchStart);
                container.removeEventListener('mousedown', sv.mouseDown);
                document.removeEventListener('touchmove', sv.touchMove);
                document.removeEventListener('mousemove', sv.mousemove);
                sv.touchStart = function (e) {
                    e.preventDefault = function () { };
                    if (originaltouchStart) {
                        originaltouchStart.apply(sv, [e]);
                    }
                };
                sv.touchMove = function (e) {
                    e.preventDefault = function () { };
                    if (originaltouchMove) {
                        originaltouchMove.apply(sv, [e]);
                    }
                };
                sv.mouseDown = function (e) {
                    e.preventDefault = function () { };
                    if (originalmouseDown) {
                        originalmouseDown.apply(sv, [e]);
                    }
                };
                sv.mouseMove = function (e) {
                    e.preventDefault = function () { };
                    if (originalmouseMove) {
                        originalmouseMove.apply(sv, [e]);
                    }
                };
                container.addEventListener("touchstart", sv.touchStart, false);
                container.addEventListener("mousedown", sv.mouseDown, false);
                document.addEventListener("touchmove", sv.touchMove, false);
                document.addEventListener("mousemove", sv.mouseMove, false);
            }
        }
    }])
    .directive('horizontalScrollFixMain', ['$timeout', '$ionicScrollDelegate', function ($timeout, $ionicScrollDelegate) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var mainScrollID = attrs.horizontalScrollFixMain,
                    scrollID = attrs.delegateHandle;

                var getEventTouches = function (e) {
                    return e.touches && (e.touches.length ? e.touches : [
                        {
                            pageX: e.pageX,
                            pageY: e.pageY
                        }
                    ]);
                };

                var fixHorizontalAndVerticalScroll = function () {
                    var mainScroll, scroll;
                    mainScroll = $ionicScrollDelegate.$getByHandle(mainScrollID).getScrollView();
                    scroll = $ionicScrollDelegate.$getByHandle(scrollID).getScrollView();

                    // patch touchstart
                    scroll.__container.removeEventListener('touchstart', scroll.touchStart);
                    scroll.touchStart = function (e) {
                        var startY;
                        scroll.startCoordinates = ionic.tap.pointerCoord(e);
                        if (ionic.tap.ignoreScrollStart(e)) {
                            return;
                        }
                        scroll.__isDown = true;
                        if (ionic.tap.containsOrIsTextInput(e.target) || e.target.tagName === 'SELECT') {
                            scroll.__hasStarted = false;
                            return;
                        }
                        scroll.__isSelectable = true;
                        scroll.__enableScrollY = true;
                        scroll.__hasStarted = true;
                        scroll.doTouchStart(getEventTouches(e), e.timeStamp);
                        startY = mainScroll.__scrollTop;

                        // below is our changes to this method
                        // e.preventDefault();

                        // lock main scroll if scrolling horizontal
                        $timeout((function () {
                            var animate, yMovement;
                            yMovement = startY - mainScroll.__scrollTop;
                            if (scroll.__isDragging && yMovement < 2.0 && yMovement > -2.0) {
                                mainScroll.__isTracking = false;
                                mainScroll.doTouchEnd();
                                animate = false;
                                return mainScroll.scrollTo(0, startY, animate);
                            } else {
                                return scroll.doTouchEnd();
                            }
                        }), 100);
                    };
                    scroll.__container.addEventListener('touchstart', scroll.touchStart);
                };
                $timeout(function () { fixHorizontalAndVerticalScroll(); });
            }
        };
    }])
    .directive('format', ['$filter', function ($filter) {
        return {
            require: '?ngModel',
            link: function (scope, elem, attrs, ctrl) {
                if (!ctrl) return;

                ctrl.$formatters.unshift(function (a) {
                    if (ctrl.$modelValue !== '') {
                        return $filter(attrs.format)(ctrl.$modelValue)
                    }
                });

                ctrl.$parsers.unshift(function (viewValue) {
                    var plainNumber = viewValue.replace(/[۰-۹]/g, function (d) {
                        return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d);
                    }).replace(/[^\d|\-+|\.+]/g, '');
                    elem.val($filter(attrs.format)(plainNumber));
                    return plainNumber;
                });
            }
        };
    }])
    .directive('validFile', function () {
        return {
            require: 'ngModel',
            link: function (scope, el, attrs, ngModel) {
                ngModel.$render = function () {
                    ngModel.$setViewValue(el.val());
                };

                el.bind('change', function () {
                    scope.$apply(function () {
                        ngModel.$render();
                    });
                });
            }
        };
    })
    .directive('rangeSlider', [function () {
        return {
            restrict: 'E',
            replace: true,
            scope: {
                config: '=',
                model: '=',
                pricevalues: '=',
                unit: '=',
            },
            template: '' +
                '<div class="range-slider-container">' +
                '<div class="range-slider-amounts">' +
                '<span> ' + lang('global.from') + ' {{config.min|number:config.precision | persianNumber}} ' + lang('global.to') + ' {{config.max|number:config.precision | persianNumber}} {{unit}}</span>' +
                '</div>' +
                '<div class="range-slider">' +
                '<div class="range-slider-set">' +
                '<div class="span-min" style="left:0;right:{{(100 - _handleMinX)}}%"></div>' +
                '<div class="span-gap" style="left:{{_handleMinX}}%;right:{{(100 - _handleMaxX)}}%"></div>' +
                '<div class="span-max" style="left:{{_handleMaxX}}%;right:0"></div>' +

                '<input type="range" class="slider-min" ng-change="_which=0" ng-model="_model[0]" min="{{_values.min}}" max="{{_values.max}}" step="1" />' +
                '<input type="range" class="slider-max" ng-change="_which=1" ng-model="_model[1]" min="{{_values.min}}" max="{{_values.max}}" step="1" />' +

                '<div class="handle from-value" style="left:{{_handleMinX}}%"><span>{{_model[0]|number:config.precision | persianNumber}}</span></div>' +
                '<div class="handle to-value" style="left:{{_handleMaxX}}%"><span>{{_model[1]|number:config.precision | persianNumber}}</span></div>' +
                '</div>' +
                '</div>' +
                '</div>',

            link: function link($scope, element) {
                var defaultConfig = {
                    gap: 0,
                    step: 1000,
                    precision: 0,
                };

                $scope.config = $.extend({}, angular.copy(defaultConfig), $scope.config);

                $scope._model = [
                    $scope.model.from,
                    $scope.model.to
                ];

                $scope._values = {
                    min: $scope.config.min || 0,
                    max: $scope.config.max || 100
                };

                $scope._labels = {
                    min: $scope._values.min,
                    max: $scope._values.max,
                };

                $scope._step = $scope.config.step || 1;

                $scope._gap = parseFloat($scope.config.gap) || 0;

                // Responsible for determining which slider the user was moving,
                // which help us resolve occurrences of sliders overlapping.
                $scope._which = 0;

                var _notInRunLoop = function _notInRunLoop() {
                    return !$scope.$root.$$phase;
                };

                var _reevaluateInputs = function () {
                    var inputElements = element.find('input');

                    $.each(inputElements, function (inputElement, index) {
                        inputElement = angular.element(inputElement);

                        inputElement.val($scope._model[index]);
                    });
                };
                var _updateModel = function _updateModel(model) {
                    $scope.model = {
                        from: parseFloat(model[0]),
                        to: parseFloat(model[1]),
                    };

                    $scope._handleMinX = (($scope._model[0] - $scope._values.min) / ($scope._values.max - $scope._values.min)) * 100;
                    $scope._handleMaxX = (($scope._model[1] - $scope._values.min) / ($scope._values.max - $scope._values.min)) * 100;
                    $scope.pricevalues.min = ($scope._model[0]);
                    $scope.pricevalues.max = ($scope._model[1]);
                    $scope._handleMinX = $scope._handleMinX < 0 ? 0 : $scope._handleMinX;
                    $scope._handleMaxX = $scope._handleMaxX > 100 ? 100 : $scope._handleMaxX;

                    if (_notInRunLoop()) {
                        try {
                            // Sometimes we're outside of the Angular run-loop,
                            // and therefore need to manually invoke the `apply` method!
                            $scope.$apply();
                        } catch (e) { }
                    }

                };

                $scope.$watch('config', function (n, o) {
                    $scope.config = $.extend({}, angular.copy(defaultConfig), $scope.config);
                    if (n && o && n !== o) {
                        $scope.config.min = parseFloat($scope.config.min);
                        $scope.config.max = parseFloat($scope.config.max);
                        $scope.config.gap = parseFloat($scope.config.gap);
                        $scope.config.step = parseFloat($scope.config.step);
                        $scope._gap = $scope.config.gap;
                        $scope._step = $scope.config.step;

                        $scope._values = {
                            min: $scope.config.min || 0,
                            max: $scope.config.max || 100
                        };

                        $scope._labels = {
                            min: $scope.config.labels.min || $scope._values.min,
                            max: $scope.config.labels.max || $scope._values.max
                        };

                        _reevaluateInputs();
                    }
                }, true);

                $scope.$watchCollection('_model', function modelChanged() {
                    $scope._model[0] = parseFloat($scope._model[0]) * 1;
                    $scope._model[1] = parseFloat($scope._model[1]) * 1;

                    // User was moving the first slider.
                    if ($scope._which === 0 && $scope._model[1] - $scope._gap < $scope._model[0]) {
                        $scope._model[1] = $scope._model[0] + $scope._gap;
                    }

                    // Otherwise they were moving the second slider.
                    if ($scope._which === 1 && $scope._model[0] + $scope._gap > $scope._model[1]) {
                        $scope._model[0] = $scope._model[1] - $scope._gap;
                    }

                    // Constrain to the min/max values.
                    (function constrainMinMax() {
                        if ($scope._model[0] < $scope._values.min) {
                            $scope._model[0] = $scope._values.min;
                        }

                        if ($scope._model[1] < $scope._values.min) {
                            $scope._model[1] = $scope._values.min;
                        }

                        if ($scope._model[0] > $scope._values.max) {
                            $scope._model[0] = $scope._values.max;
                        }

                        if ($scope._model[1] > $scope._values.max || $scope._model[1] == $scope._values.max) {
                            $scope._model[1] = $scope._values.max;
                        }

                        // mind the gap
                        var _m0Gap = $scope._model[0] + $scope._gap;
                        var _m1Gap = $scope._model[1] - $scope._gap;

                        if ($scope._model[0] > _m1Gap) {
                            $scope._model[0] = _m1Gap;
                        }

                        if ($scope._model[1] < _m0Gap) {
                            $scope._model[1] = _m0Gap;
                        }
                    })();
                    // Update the model!
                    _updateModel($scope._model);
                    _reevaluateInputs();
                });
            }
        };
    }])
    .directive('validateNationalCode', function () {
        return {
            require: 'ngModel',
            link   : function (scope, element, attr, mCtrl) {
                function vmsNationalCode(input) {
                    if (!/^\d{10}$/.test(input) ||
                        /(123456789)/.test(input) ||
                        input == '0000000000' ||
                        input == '1111111111' ||
                        input == '2222222222' ||
                        input == '3333333333' ||
                        input == '4444444444' ||
                        input == '5555555555' ||
                        input == '6666666666' ||
                        input == '7777777777' ||
                        input == '8888888888' ||
                        input == '9999999999') {
                        mCtrl.$setValidity('validCode', false);
                        return false;
                    }
                    var check = parseInt(input[9]);
                    var sum = 0;
                    var i;
                    for (i = 0; i < 9; ++i) {
                        sum += parseInt(input[i]) * (10 - i);
                    }
                    sum %= 11;
                    var resalt = (sum < 2 && check == sum) || (sum >= 2 && check + sum == 11);
                    mCtrl.$setValidity('validCode', resalt);
                    return input;
                }

                mCtrl.$parsers.push(vmsNationalCode);
            }
        };
    })

    .filter('toman', function () {
        return function (input) {
            if (input && lang('global.locale') == 'fa') {
                input = input.replace(/\.[^.]*$/g, '');
                input = input.replace(/0/g, '۰').replace(/1/g, '۱').replace(/2/g, '۲').replace(/3/g, '۳').replace(/4/g, '۴').replace(/5/g, '۵').replace(/6/g, '۶').replace(/7/g, '۷').replace(/8/g, '۸').replace(/9/g, '۹');
                return input + ' ' + lang('global.toman');
            }
            return input;
        }
    })
    .filter('lang', function () {
        return lang
    })
    .filter('secondsToHMS', function () {
        return function (input) {
            if (input) {
                var date = new Date(0, 0, 0, 0, 0, input);
                var h = (date.getDay() * 24) + (date.getHours());
                h = h + ':';
                var m = (date.getMinutes());
                m = m + ':';
                var s = (date.getSeconds());
                return (h + m + s);
            }
        }
    })
    .filter('persianNumber', function () {
        return function (input) {
            if (typeof input !== "undefined" && lang('global.locale') == 'fa') {
                return input.toString().replace(/0/g, '۰').replace(/1/g, '۱').replace(/2/g, '۲').replace(/3/g, '۳').replace(/4/g, '۴').replace(/5/g, '۵').replace(/6/g, '۶').replace(/7/g, '۷').replace(/8/g, '۸').replace(/9/g, '۹');
            }
            return input;
        }
    })
    .filter('isNotEmptyStringAndDash', function () {
        return function (value) {
            return (
                (typeof value != 'undefined')        //undefined
                &&
                (value != null)                     //null
                &&
                (value != false)                    //false
                &&
                (value.length != 0)                 //empty
                &&
                (value != "")                       //empty
                &&
                (value.replace(/\s/g, "") != "")     //empty
                &&
                (/[^\s]/.test(value))              //empty
                &&
                (!/^\s*$/.test(value))               //empty
                &&
                (value.indexOf('-') == -1)               //dash
            );
        }
    })
    .filter('isEmptyString', function () {
        return function (value) {
            return (
                (typeof value == 'undefined')        //undefined
                ||
                (value == null)                     //null
                ||
                (value == false)                    //false
                ||
                (value.length == 0)                 //empty
                ||
                (value == "")                       //empty
                ||
                (value.replace(/\s/g, "") == "")     //empty
                ||
                (!/[^\s]/.test(value))              //empty
                ||
                (/^\s*$/.test(value))               //empty
            );
        }
    })
    .filter('trusted', ['$sce', function ($sce) {
        return function (url) {
            return $sce.trustAsResourceUrl(url);
        };
    }])
    .filter('trustedHtml', ['$sce', function ($sce) {
        return function (plainText) {
            return $sce.trustAsHtml(plainText);
        };;
    }])
    .filter('itemType', function () {
        return function (input, type) {
            switch (type) {
                case 'stateSelect':
                    return typeof input == "object" ? Object.values(input).join(', ') : '';
                case 'multiplechoice':
                    return typeof input == "object" ? Object.keys(input).join(', ') : '';
                case 'checkbox':
                case 'toggle':
                    return input === true ? '✔' : '✘';
                default:
                    if (typeof input == "object") {
                        Object.values(input).join(', ');
                    }
                    return input;
            }
        };
    })
    .filter('convertUnit', function () {
        return function (input) {
            if (input >= 1000) {
                input = input / 1000;
                input = input.toFixed(1);
                return input + lang('global.thousand');
            } else if (input >= 1000000) {
                input = input / 1000000;
                input = input.toFixed(1);
                return input + lang('global.million');
            }
            return input;
        }
    });

function getValue(obj, i) { return obj[i] }
function lang(key) {
    try {
        var trans = key.split('.').reduce(getValue, _lang);
        return typeof trans != "undefined" ? trans : key;
    }
    catch (err) {
        return key;
    }
}
