var locale = 'en';
var url = 'https://app.puzzley.net';
var online = true,
    $show_ad = true,
    isDevice = true,
    check = false,
    phone_id = '',
    default_access_page = [],
    trialMode = true,
    $app_data = {
        t: '1730354717',
        version: '0.1.0',
        target_market: "iRANCOiN",
        layout: 'new-tabs-bottom',
        last_seen: parseInt((new Date()).getTime()/1000),
        date_format: 'jalali',
        app_name: 'iRANCOiN'
    },
    $app_sl = 'eyJpdiI6ImRxWC9ITnNzUzl0bC9BN2tGOG9DR0E9PSIsInZhbHVlIjoiL2tPandHQzhPOU5qYnZhMVNaY1Y3d0U2RElMSVVpYWUvYW9TU2FDTzM4Zz0iLCJtYWMiOiI4YWNjNTg1ZDMyM2M1ZjVhZGY0Y2U0ZGY1YTZiZjMwODkwN2YxMWIwNDc1ZGIxYTEyNWFlMzg2MGZkYzM3ZDFmIiwidGFnIjoiIn0%3D',
    $device_info = {};

var ngApp = angular.module('ngApp', ['ionic', 'ngResource', 'ngApp.controllers', 'ngApp.services', 'ionic-datepicker'])
    .run(function($ionicPlatform, $rootScope, $ionicLoading, $ionicHistory, $ionicPopup, $state, $ionicModal, $ionicScrollDelegate, $location , Auth) {
        $rootScope.$on('loading:show', function() {
            $ionicLoading.show({
                noBackdrop: true
            });
        });

        $rootScope.$on('loading:hide', function() {
            $ionicLoading.hide();
        });

        $rootScope.isDevice = isDevice;
        $rootScope.app_data = $app_data;
        // Show IOS tutorial popup
        var showIosTutorialPopup = function (e) {
            if (e.isStandalone) {
                return;
            }

            if (e.isEmulator) {
                return;
            }

            if (!e.isIOS) {
                return;
            }

            if (e.isWebView) {
                return;
            }

            $rootScope.openIOSTutorialModal();
        }

        // Show Android tutorial popup
        var showAndroidTutorialPopup = function (e) {
            if (e.isStandalone) {
                return;
            }

            if (e.isEmulator) {
                return;
            }

            if (!e.isAndroid) {
                return;
            }

            if (e.isWebView) {
                return;
            }

            $rootScope.openAndroidTutorialModal();
        }

        // Check if application load in web app or device
        // ATTENTION: The emulator in explorers is not our
        // target for this feature. just mobile devices.
        var executeDeviceReadyFunctions = function () {
            var event = {
                isAndroid: ionic.Platform.isAndroid(),
                isIOS: ionic.Platform.isIOS(),
                isStandalone: ionic.Platform.isAndroid() ? window.matchMedia('(display-mode: standalone)').matches : window.navigator.standalone === true,
                // We are in the emulator then should not do anythings
                isEmulator: window.location.pathname.match(/^\/mobile\//) ? true : false,
                isWebView: ionic.Platform.isWebView()
            };

            window.platform_info = event;

            // Dispach event
                            showIosTutorialPopup(event);
                showAndroidTutorialPopup(event);
                                                    if (window.plugins && window.plugins.preventscreenshot) {
                    window.plugins.preventscreenshot.disable(function(){
                        console.log('preventscreenshot is on');
                    }, function(){});
                }
                        setTimeout(checkapp, 3000); //wait for app setup completley
        }

        $rootScope.goToStateWithDisableBack = function (to) {
            $ionicHistory.nextViewOptions({
                    historyRoot: true,
                    disableBack: true
            });
            $state.go(to, {}, {
                location: "replace",
                reload: true
            });
            setTimeout(function(){
                $ionicHistory.clearHistory();
            },500);
        }

        $rootScope.dataTapStatus = false;

        $ionicPlatform.ready(function() {
            /*Auth.init();*/

            // Execute all neccessary function when device was ready
            executeDeviceReadyFunctions();
        });

        $rootScope.backButtonPressedOnceToExit = false;
        $ionicPlatform.registerBackButtonAction(function(e) {
            e.preventDefault();
            if ($rootScope.backButtonPressedOnceToExit) {
                ionic.Platform.exitApp();
            }
                            else if ($rootScope.user && !$rootScope.user.isLogin) {
                    var backView = $ionicHistory.backView();
                    if (backView && ('#' + backView.url) == signupHash) {
                        $ionicHistory.goBack();
                    } else {
                        $rootScope.backButtonPressedOnceToExit = true;
                        showToast(lang('global.press_again_to_exit'), 2000);
                        setTimeout(function() {
                            $rootScope.backButtonPressedOnceToExit = false;
                        }, 2500);
                    }
                }
                        else if (window.location.hash.indexOf("web-page") !== -1) {
                window.history.back();
                if (window.location.hash == homeHash) {
                    $rootScope.backButtonPressedOnceToExit = true;
                    setTimeout(function() {
                        $rootScope.backButtonPressedOnceToExit = false;
                    }, 300);
                }
            } else if ($ionicHistory.backView()) {
                $ionicHistory.goBack();
            } else if (hasHome && window.location.hash != homeHash) {
                $ionicHistory.nextViewOptions({
                    disableBack: true
                });
                window.location.hash = homeHash;
            } else {
                $rootScope.backButtonPressedOnceToExit = true;
                showToast(lang('global.press_again_to_exit'), 2000);
                setTimeout(function() {
                    $rootScope.backButtonPressedOnceToExit = false;
                }, 2500);
            }
            return false;
        }, 101);

        
        var signup_show_upgrade_plan = false;
        $rootScope.$on('$stateChangeStart', function(event, toState, toStateParams, fromState, fromStateParams) {
                            $rootScope.hideTabs = (toStateParams.widget && toStateParams.widget == 'e-commerce' && (toStateParams.func ==
                "getSingle" || toStateParams.func == "getCartView"));
            
            if ($rootScope.openPopup)
                $rootScope.openPopup.close();
            if($rootScope.openModal)
                $rootScope.openModal.hide();

                                    if (
                (toState.pageid != 1 && !Auth.CanAccess(toState.pageid))
                || (typeof toStateParams.pageid != 'undefined' && !Auth.CanAccess(toStateParams.pageid))
                || (
                    typeof toStateParams.id !== 'undefined'
                    && toStateParams.id != 1
                    && !Auth.CanAccess(toStateParams.id)
                    && toStateParams.func == 'getIndex'
                    )
            ) {
                event.preventDefault();
                if(Auth.Check()) {
                    if (!Auth.User.hideUpgradeButton){
                        $ionicPopup.confirm({
                            cssClass: 'signup_pupop',
                            title: 'عدم دسترسی',
                            template: '<p style="text-align: left;">شما به این صفحه دسترسی ندارید</p>',
                            okText: 'ارتقا',
                            okType: 'button-clear button-balanced',
                            cancelText: 'انصراف',
                            cancelType: 'button-clear button-assertive',
                        }).then(function(confirm) {
                            if (confirm) {
                                window.location.hash = '#/nav/widget/signup/selectPlan/eyJpdiI6Ik9vakRVUmd5dk9yU3ZWWVR4WTVneGc9PSIsInZhbHVlIjoiMEVXMFc3NVZCeHM4QnV6L0tYQTF4VlBFQmUwSWgyWEg5cGp6VnZCY1N1ZE9iVXA3MncwNWVVMENCaEcwQnBRRCIsIm1hYyI6IjMwZTc5NWUxZDI3ODIzY2Q1ODc4MjgwYjljYmRlN2U1MDZhNDM0YzYxNjBlMmE5ZmRlZWQwYTI4YzY5ODQyNzQiLCJ0YWciOiIifQ%3D%3D/1';
                            }
                        });
                    } else {
                        $ionicLoading.show({
                            template:'<div class="info"><i class="icon warning ion-ios-information-outline"></i></div><div><p style="text-align: left;">شما به این صفحه دسترسی ندارید</p></div>'
                        });
                        setTimeout(function () {
                            $ionicLoading.hide();
                        }, $widgets.data.signup.no_access_message_time);
                    }
                } else {
                    $rootScope.forceToLoggedIn('<p>برای دسترسی به این صفحه باید ثبت&zwnj;نام کنید</p>');
                }
            }
                    });

                $rootScope.forceToLoggedIn = function (message) {
            if (Auth.Check()) {
                return;
            }
            $widgets.data.signup.redirectAfterLogin = window.location.hash;

            $ionicPopup.confirm({
                cssClass: 'signup_pupop',
                title: 'حساب کاربری',
                template: typeof message == "undefined" ? 'برای دسترسی به این امکان باید حتما وارد شوید' : message,
                okText: 'ورود',
                okType: 'button-clear button-balanced',
                cancelText: 'انصراف',
                cancelType: 'button-clear button-assertive',
            }).then(function(confirm) {
                if (confirm) {
                    $state.go('nav.signup249');
                }
            });
        }
        $rootScope.showForceLoginPopup = function () {
            if (Auth.Check()) {
                return;
            }

            $widgets.data.signup.redirectAfterLogin = window.location.hash;
            $ionicPopup.confirm({
                cssClass: 'signup_pupop',
                title: 'حساب کاربری',
                template: 'برای دسترسی به این امکان باید حتما وارد شوید',
                buttons: [
                    {
                        text: "انصراف",
                        type: 'button-clear button-assertive',
                        onTap:function(e){
                            $ionicHistory.goBack();
                        }
                    },
                    {
                        text: "ورود",
                        type: 'button-clear button-balanced',
                        onTap:function(e){
                            $state.go('nav.signup249');
                        }
                    },
                ]
            });
        }

        $rootScope.isUserLoggedIn = function () {
            return Auth.Check();
        }
        
        $rootScope.iOSTutorialModal = $ionicModal.fromTemplate(
            '<ion-modal-view>' +
                '<ion-content class="webapp-help ios rtl">'+
                    '<div style="display: flex;flex-direction: column;">' +
                        '<div style="flex:1;">' +
                            '<div style="display: flex;justify-content: center; margin-top: 20%;">' +
                                '<img src="https://app.puzzley.net/uploads/attachments/App/headers/000/216/513/icon40/logo.png" style="">' +
                            '</div>' +

                            '<div style="display: flex;justify-content: center;text-align: center;margin: 15px 15%;">' +
                                'وب‌اپلیکیشن " iRANCOiN " را به صفحه اصلی موبایل خود اضافه کنید.' +
                            '</div>' +

                            '<div class="theme-bg-simple" style="display: block;width: 80vw;height: 4px;margin: auto;"></div>' +
                            '<div style="margin: 0 10%;">' +
                                '<ul style="margin-top: 10px;">' +
                                    '<li style="line-height:50px">١- در نوار پایین روی دکمه <b>share</b> <svg enable-background="new 0 0 50 50" height="25px" id="Layer_1" version="1.1" viewBox="0 0 50 50" width="25px" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="vertical-align: middle;"><polyline fill="none" points="17,10 25,2 33,10   " stroke="#007AFF" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2"></polyline><line fill="none" stroke="#007AFF" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2" x1="25" x2="25" y1="32" y2="2.333"></line><rect fill="none" height="50" width="50"></rect><path d="M17,17H8v32h34V17h-9" fill="none" stroke="#007AFF" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2"></path></svg> بزنید.</li>' +
                                    '<li>۲- در قسمت پایین از منوی باز شده، گزینه <b> Install app(نصب برنامه) </b> را انتخاب کنید.</li>' +
                                    '<img src="/assets/images/add-to-homescreen.png" style="margin-top:25px;margin-bottom:25px;width:100%;">' +
                                    '<li>۳- در مرحله بعد در قسمت بالا روی <b style="color:#007AFF;">Add</b> بزنید.</li>' +
                                '</ul>' +
                            '</div>' +
                        '</div>' +

                        '<div style="margin:5px;margin-top: 25px;">' +
                            '<button class="button button-block button-balanced" ng-click="closeIOSTutorialModal()" style="width: 80%;margin: auto;">' +
                                'تایید' +
                            '</button>' +
                        '</div>' +
                    '</div>' +
                '</ion-content>' +

            '</ion-modal-view>', {
                scope: $rootScope,
                animation: 'slide-in-up'
            });

        $rootScope.openIOSTutorialModal = function() {
            $rootScope.iOSTutorialModal.show();
        };

        $rootScope.closeIOSTutorialModal = function() {
            $rootScope.iOSTutorialModal.hide();
        };

        $rootScope.androidTutorialModal = $ionicModal.fromTemplate(
            '<ion-modal-view>' +
                '<ion-content class="webapp-help android rtl">'+
                    '<div style="display: flex;flex-direction: column;">' +
                        '<div style="flex:1;">' +
                            '<div style="display: flex;justify-content: center; margin-top: 20%;">' +
                                '<img src="https://app.puzzley.net/uploads/attachments/App/headers/000/216/513/icon40/logo.png" style="">' +
                            '</div>' +

                            '<div style="display: flex;justify-content: center;text-align: center;margin: 15px 15%;">' +
                                'وب‌اپلیکیشن " iRANCOiN " را به صفحه اصلی موبایل خود اضافه کنید.' +
                            '</div>' +

                            '<div class="theme-bg-simple" style="display: block;width: 80vw;height: 4px;margin: auto;"></div>' +
                            '<div style="margin: 0 10%;">' +
                                '<ul style="margin-top:10px;">' +
                                    '<li style="margin:25px 0;">١- در قسمت گوشه سمت راست دکمه <b>settings</b> <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style="width: 20px;vertical-align: middle;enable-background:new 0 0 512 512;" xml:space="preserve"><g><g><g><circle cx="256" cy="256" r="64"></circle><circle cx="256" cy="448" r="64"></circle><circle cx="256" cy="64" r="64"></circle></g></g></g></svg> را بزنید.</li>' +
                                    '<li style="margin-bottom:25px;">۲- در قسمت پایین از منوی باز شده، گزینه <b> Install app(نصب برنامه) </b> را انتخاب کنید.</li>' +
                                    '<li style="margin-bottom:25px;">۳- در قسمت پایین روی <b style="color:#007AFF;">Add</b> بزنید.</li>' +
                                '</ul>' +
                            '</div>' +
                        '</div>' +

                        '<div style="margin:5px;margin-top: 25px;">' +
                            '<button class="button button-block button-balanced" ng-click="closeAndroidTutorialModal()" style="width: 80%;margin: auto;">' +
                                'تایید' +
                            '</button>' +
                        '</div>' +
                    '</div>' +
                '</ion-content>' +

            '</ion-modal-view>', {
                scope: $rootScope,
                animation: 'slide-in-up'
            });

        $rootScope.openAndroidTutorialModal = function() {
            $rootScope.androidTutorialModal.show();
        };

        $rootScope.closeAndroidTutorialModal = function() {
            $rootScope.androidTutorialModal.hide();
        };

        $rootScope.openImageViewerModal = function(src) {
            $rootScope.imageViewerModal = $ionicModal.fromTemplate(
                '<div class="modal image-viewer-modal transparent ltr" on-swipe-down="closeImageViewerModal()">'+
                    '<div class="transparent-bar">'+
                        '<div class="back" ng-click="closeImageViewerModal()"><i class="ion-close-round"></i></div>'+
                    '</div>'+
                    '<ion-scroll class="imageContiner" direction="xy" scrollbar-x="false" scrollbar-y="false" zooming="true" min-zoom="1" delegate-handle="imageviewer-zoom-pane" overflow-scroll="false">'+
                        '<span></span>'+
                        '<img ng-src="{{ ImageViewerPhoto }}" on-double-tap="zoom()" />'+
                    '</ion-scroll>'+
                    '<div class="caption rtl">'+
                                                '<div class="photo-download">'+
                            '<a href="{{ ImageViewerPhoto }}" target="_system" download>' +
                                '<i class="ion-android-download"></i>'+
                            '</a>' +
                        '</div>'+
                                                                    '</div>'+
                '</div>', {
                scope: $rootScope,
                animation: 'slide-in-up',
                hardwareBackButtonClose: true
            });
            $rootScope.ImageViewerPhoto = src;
            $rootScope.imageViewerModal.show();
        };

        $rootScope.imageViewerModal
        $rootScope.shareImage = function(src, event) {
            shareImage('', src, event);
        };

        $rootScope.closeImageViewerModal = function() {
            $rootScope.imageViewerModal.remove();
        };

        $rootScope.inZoom = false;
        $rootScope.zoom = function(){
            if ($rootScope.inZoom) {
                $ionicScrollDelegate.$getByHandle('imageviewer-zoom-pane').zoomTo(1, true);
                $rootScope.inZoom = false;
            } else {
                $ionicScrollDelegate.$getByHandle('imageviewer-zoom-pane').zoomTo(2, true);
                $rootScope.inZoom = true;
            }
        }

        $rootScope.activeTrialMode = function(){
            $rootScope.isTrial = true;
            $rootScope.trial_message = 'نسخه دمو - آزمایشی';
            $rootScope.$apply();
            $ionicPopup.alert({
                cssClass: 'trial_pupop',
                title: 'نسخه تست',
                template: 'نسخه تست متن',
                okText: 'تایید',
                okType: 'button-clear button-balanced'
            });
            setInterval(function(){
                showToast('نسخه تست', 2800, 'center');
            }, 60000);
        }
            if (typeof updateSimpleCartInstances !== "undefined") {
                $rootScope.$on('$stateChangeSuccess', function(event, toState, toStateParams, fromState, fromStateParams) {
                    setTimeout(updateSimpleCartInstances, 600);
                });
            }
    })

    .config(function($stateProvider, $locationProvider, $urlRouterProvider, $ionicConfigProvider, $httpProvider, $compileProvider) {

                    $ionicConfigProvider.scrolling.jsScrolling(true);
        
        $compileProvider.aHrefSanitizationWhitelist(/^\s*((https?|ftp|mailto|sms|tel|geo|bazaar|store|myket|tg|instagram|javascript):)|(#\/nav\/.*)/);

        $ionicConfigProvider.templates.maxPrefetch(0);
        $ionicConfigProvider.backButton.previousTitleText(false).text('');
        $ionicConfigProvider.navBar.positionSecondaryButtons('right');
        $ionicConfigProvider.navBar.positionPrimaryButtons('left');
        $ionicConfigProvider.form.toggle('large');
        $ionicConfigProvider.form.checkbox('circle');

        $httpProvider.interceptors.push(function($rootScope, $q) {
            return {
                /* http request show loading */
                request: function(config) {
                    if (typeof config.noLoading == "undefined" || config.noLoading != true) {
                        $rootScope.$broadcast('loading:show');
                    }
                    return config
                },
                /* Hide loading in case any occurred */
                requestError: function(response) {
                    $rootScope.$broadcast('loading:hide');
                    return response
                },
                /* Hide loading once got response */
                response: function(response) {
                    $rootScope.$broadcast('loading:hide');
                    return response
                },
                /* Hide loading if got any response error  */
                responseError: function(response) {
                    $rootScope.$broadcast('loading:hide');
                    return $q.reject(response);
                }
            }
        });

                    $ionicConfigProvider.tabs.position("bottom");
        
        $ionicConfigProvider.navBar.alignTitle('center');

        $stateProvider
            .state('nav', {
                url: '/nav',
                abstract: true,
                templateUrl: 'nav.html',
                controller: 'NavCtrl',
                secured: 0,
                pageid: 1
            })
            .state('nav.widget1', {
                url: '/widget/:widget/:func/:sl/:id',
                views: {
                    'mainContent': {
                        templateUrl: function(params) {
                            if (!isOnline()) { checkYourInternet(); }
                            return url + '/api/v1/widget/route/' + params.widget + '/' + params.func + '/' + params.sl + '/' + params.id;
                        }
                    }
                },
                secured: 0,
                pageid: 1
            })
            .state('nav.widget2', {
                url: '/widget/:widget/:func/:sl/:id/:extra',
                views: {
                    'mainContent': {
                        templateUrl: function(params) {
                            if (!isOnline()) { checkYourInternet(); }
                            return url + '/api/v1/widget/route/' + params.widget + '/' + params.func + '/' + params.sl + '/' + params.id + '/' + params.extra;
                        }
                    }
                },
                secured: 0,
                pageid: 1
            })
            .state('nav.widget3', {
                url: '/online/:widget/:func/:pageid/:sl/:itemid',
                views: {
                    'mainContent': {
                        templateUrl: function(params) {
                            if (!isOnline()) { checkYourInternet(); }
                            return url + '/api/v1/widget/route/' + params.widget + '/' + params.func + '/' + params.sl + '/' + params.itemid ;
                        }
                    }
                },
                secured: 0,
                pageid: 1
            })
            .state('nav.watermarkPage', {
                url: "/watermarkPage",
                views: {
                    'mainContent': {
                        templateUrl: 'appwatermark.html'
                    }
                },
                secured: 0,
                pageid: 1
            })
                        .state('nav.morePage216513', {
                url: "/morePage216513",
                views: {
                    'mainContent': {
                        templateUrl: 'more-modal.html'
                    }
                },
                secured: 0,
                pageid: 1
            })
            
                        .state('nav.home-screen723', {
                url: '/home-screen723',
                cache: 'true',
                secured : 0,
                pageid : '1',
                views: {
                    'mainContent': {
                        templateUrl: 'templates/home-screen723.html'
                    }
                }
            })
                        .state('nav.signup249', {
                url: '/signup249',
                cache: 'true',
                secured : 0,
                pageid : '1',
                views: {
                    'mainContent': {
                        templateUrl: 'templates/signup249.html'
                    }
                }
            })
                        .state('nav.web-page885', {
                url: '/web-page885',
                cache: 'false',
                secured : 0,
                pageid : '1615682',
                views: {
                    'mainContent': {
                        templateUrl: 'templates/web-page885.html'
                    }
                }
            })
                        .state('nav.web-page167', {
                url: '/web-page167',
                cache: 'false',
                secured : 0,
                pageid : '1615683',
                views: {
                    'mainContent': {
                        templateUrl: 'templates/web-page167.html'
                    }
                }
            })
                        .state('nav.web-page723', {
                url: '/web-page723',
                cache: 'false',
                secured : 0,
                pageid : '1615684',
                views: {
                    'mainContent': {
                        templateUrl: 'templates/web-page723.html'
                    }
                }
            })
                        .state('nav.web-page502', {
                url: '/web-page502',
                cache: 'false',
                secured : 0,
                pageid : '1615685',
                views: {
                    'mainContent': {
                        templateUrl: 'templates/web-page502.html'
                    }
                }
            })
                        .state('nav.raychat620', {
                url: '/raychat620',
                cache: 'true',
                secured : 0,
                pageid : '1615686',
                views: {
                    'mainContent': {
                        templateUrl: 'templates/raychat620.html'
                    }
                }
            })
                        .state('nav.rss710', {
                url: '/rss710',
                cache: 'true',
                secured : 0,
                pageid : '1615687',
                views: {
                    'mainContent': {
                        templateUrl: 'templates/rss710.html'
                    }
                }
            })
            
        
                    .state('nav.feed', {
                url: "/feeds/:entryId/:hashCode",
                views: {
                    'mainContent': {
                        template: '<ion-view title="{{entry.title}}"><ion-content class=""><div><img class="margin-negative2 share-image" width="100%" ng-if="entry.feedImage" ng-src="{{entry.feedImage}}"></div><h3 class="transparent header-product title item_name position-relative margin-top-header item-contact share-title"> {{entry.title}} </h3><div class="transparent feed tabs-contents item-contact" ><div class="inform" ng-show="entry.author"><i class="ion-person"></i><span ng-bind-html="entry.author"></span></div><p ng-bind-html="entry.content" class="feedcontent share-message"></p><a class="category" ng-repeat="category in entry.categories">{{category}}</a><span class="share-url ng-hide" data-share-url="{{entry.link}}"></span><center><button class="icon-left ion-share button-custom item-circle2" ng-click="loadURL()"></button></center> </div></ion-content></ion-view>',
                        controller: 'FeedCtrl'
                    }
                },
                secured: 0,
                pageid: 1
            })
        
                ;
        var first_slug = 'home-screen723';
        try {
            var user;
            if (true && localStorage.user && (user = JSON.parse(localStorage.user)) && user.isLogin) {
                first_slug = user.homePageSlug ? user.homePageSlug : first_slug;
            } else if (true) {
                first_slug = 'signup249';
            }
        } catch (error) {}
        $urlRouterProvider.otherwise('/nav/' + first_slug);
    });

    var appsetting = (localStorage.app216513setting) ? JSON.parse(localStorage.app216513setting) : {};
    appsettingInit();

function saveSetting() {
    localStorage.app216513setting = JSON.stringify(appsetting)
}

document.addEventListener("online", function() {
    online = true;
}, false);
document.addEventListener("offline", function() {
    online = false;
}, false);
function isOnline() {
    return online;
}

var homeHash = "#/nav/home-screen723";
var homeState = "nav.home-screen723";
var hasHome = true;
/* iap message */
    var signupHash = "#/nav/signup249";

function checkapp() {
    if (!check) {
        if (typeof device == "object") {
            $device_info.platform = device.platform;
            $device_info.version = device.version;
            if ($app_data.target_market !== 'googleplay') {
                $device_info.uuid = device.uuid;
            }
            $device_info.model = device.model;
        }
        check = true;
        $.post(url + '/api/v1/app/check-app/K1xLq',{
            device: $device_info,
            app_data : $app_data
        })
            .done(function(data) {
                if (typeof(data.active) != 'undefined' && data.active == 0) {
                    alert('این اپلیکیشن غیرفعال است.');
                    window.localStorage['active'] = 'notActive';
                    ionic.Platform.exitApp();
                } else if (typeof(data.active) != 'undefined' && data.active == 1) {
                    window.localStorage['active'] = true;
                }
            }).fail(function() {
                if (window.localStorage['active'] == 'notActive') {
                    alert('این اپلیکیشن غیرفعال است.');
                    ionic.Platform.exitApp();
                }
                check = false;
            });
    }
}
document.addEventListener("deviceready", function() {
    setTimeout(function() {
        if (window.localStorage['active'] == 'notActive') {
            alert('این اپلیکیشن غیرفعال است.');
            ionic.Platform.exitApp();
        }
    }, 10000);
    document.addEventListener("online", function() {
        setTimeout(checkapp, 6000);
    }, false);
    isDevice = true;
    var $rootScope = angular.element(document.body).injector().get('$rootScope');
    $rootScope.isDevice = true;
    $rootScope.$apply();
    setTimeout(function() {
        $('body').on('click', 'a[target="_system"]', function(e) {
            e.preventDefault();
            var src = $(this).attr("href");
            if (typeof cordova !== 'undefined' && typeof cordova.InAppBrowser !== 'undefined') {
                cordova.InAppBrowser.open(encodeURI(fullyDecodeURI(src)), '_system');
            } else {
                window.open(src, '_system');
            }
        });
        $('body').on('click', 'a[target="_blank"]', function(e) {
            e.preventDefault();
            var src = $(this).attr("href");
            if (typeof cordova !== 'undefined' && typeof cordova.InAppBrowser !== 'undefined') {
                cordova.InAppBrowser.open(encodeURI(fullyDecodeURI(src)), '_system');
            } else {
                window.open(src, '_system');
            }
        });
    }, 3000);

    if (trialMode) {
        $rootScope.activeTrialMode();
    }
    StatusBar.backgroundColorByHexString(toHexColor('#fccf22'));
});


function isEncoded(uri) {
    uri = uri || '';
    return uri !== decodeURIComponent(uri);
}

function fullyDecodeURI(uri){
    while (isEncoded(uri)){
        uri = decodeURIComponent(uri);
    }
    return uri;
}



var logArray = ['','','','',''];
function showLog(message) {
    logArray.shift();
    logArray.push(message);
    var x = document.getElementById("toastMessage");
    x.innerHTML = logArray.join('<br>');
    x.className = "show";
    setTimeout(function () {
        x.className = x.className.replace("show", "");
    }, 3000);
}

setTimeout(function () {
    $('body').on('click', '.image-viewer img', function() {
        if (!$(this).parents('a').length && (this.naturalWidth >= 50 || this.naturalHeight >= 50)) {
            var src = $(this).attr('src');
            angular.element(document.body).injector().get('$rootScope').openImageViewerModal(src);
        }
    });
}, 1000);

setTimeout(function () {
    $('body').on('click', '.toggleSideMenu', function() {
        angular.element(document.body).injector().get('$rootScope').toggleSideMenu();
    });
}, 3000);

if(window.localStorage['last_seen']) {
    $app_data.last_seen = parseInt(window.localStorage['last_seen']);
}
window.localStorage['last_seen'] = parseInt((new Date()).getTime()/1000);
