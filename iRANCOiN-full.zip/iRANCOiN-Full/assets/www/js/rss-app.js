angular.module('ngApp')
	// RSS Feeds Controller
	.controller('RssCtrl', function ($scope, $http, localStorage) {
		$scope.feeds = [];
		$scope.storage = '';
		var data;

		$scope.$watch('sl', function () {
			$scope.showFeed(false);
		});

		$scope.showFeed = function (refresh) {
			data = localStorage.all($scope.hash);
			if (data) {
				$scope.feeds = data.entries;
			}
			if (isOnline()) {
				if (!refresh) {
					$scope.loading = true;
				}

				$http({
						method: 'GET',
						noLoading: true,
						url: url + '/api/v1/widget/get/rss/getFeed?sl=' + $scope.sl
					})
					.success(function (data) {
						$scope.$broadcast('scroll.refreshComplete');
						if (data) {
							data.entries = $scope.getFirstImage(data.entries);
							$scope.storage = data.error;
							localStorage.save(data, $scope.hash);
							$scope.feeds = data.entries;
						} else {
							$scope.storage = lang('global.connection_error');
						}
						$scope.loading = false;
					})
					.error(function () {
						checkYourInternet();
						$scope.$broadcast('scroll.refreshComplete');
						data = localStorage.all($scope.hash);
						$scope.storage = lang('global.connection_error');
						$scope.feeds = data.entries;
						$scope.loading = false;
					});
			} else {
				$scope.loading = false;
				checkYourInternet();
				$scope.storage = lang('global.connection_error') + '<br>' + lang('global.check_your_internet_connection');
			}
		}

		$scope.doRefresh = function () {
			$scope.showFeed(true);
		};

		$scope.getFirstImage = function (entries) {
			for (i = 0; i < entries.length; i++) {
				if (entries[i].image == '') {
					var tagIndex = entries[i].content.indexOf('<img');
					if (tagIndex >= 0) {
						var srcIndex = entries[i].content.substring(tagIndex).indexOf('src=') + tagIndex; // Find where the src attribute starts
						var srcStart = srcIndex + 5; // Find where the actual image URL starts; 5 for the length of 'src="'
						var srcEnd = entries[i].content.substring(srcStart).indexOf('"') + srcStart; // Find where the URL ends
						var src = entries[i].content.substring(srcStart, srcEnd);
						entries[i].image = src;
					}
				} else {
					entries[i].feedImage = entries[i].image;
				}
			}
			return entries;
		};

	})

	// RSS Feed Controller
	.controller('FeedCtrl', function ($scope, $stateParams, localStorage) {
		var data = localStorage.all($stateParams.hashCode);
		$scope.entry = data.entries[$stateParams.entryId];

		$scope.loadURL = function () {
			openPaymentUrl($scope.entry.link);
		}

		$scope.shareEntry = function () {
			var message = $scope.entry.title;
			message = message.replace(/(<([^>]+)>)/ig, "");
			message = message.substring(0, 100);
			message = message + ' ...';

			var link = $scope.entry.link;
			window.plugins.socialsharing.share(null, message, null, link);
		}
	});